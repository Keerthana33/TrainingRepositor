﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _496105_caselet
{
    class OutPatient : PatientDetails
    {
        int roomNo;
        DateTime admitDate;
        DateTime dischargeDate;
        double fee;
        double minRentOfDay;
        string consultingDoctor;

        public int RoomNo
        {
            get { return roomNo; }
            set { roomNo = value; }
        }
        public DateTime AdmitDate
        {
            get { return admitDate; }
            set { admitDate = value; }
        }
        public DateTime DischargeDate
        {
            get { return dischargeDate; }
            set { dischargeDate = value; }
        }
        public double Fee
        {
            get { return fee; }
            set { fee = value; }
        }
        public double MinRentOfDay
        {
            get { return minRentOfDay; }
            set { minRentOfDay = value; }
        }
        public string ConsultingDoctor
        {
            get { return consultingDoctor; }
            set { consultingDoctor = value; }
        }

        List<OutPatient> outPatientList = new List<OutPatient>();

        public OutPatient()
        {
        }

        public override string ToString()
        {
            return "Patient Name:" + PatientName + "\nAge:" + PatientAge + "\nDate Of Birth:" +
                PatientDOB.ToShortDateString() + "\nAddress:" + PatientAddress + "\nDoctor:" + ReferringDoctor +
                "\nAdmit Date:" + AdmitDate + "\nRoom No::" + RoomNo + "\nDischarge Date:" + DischargeDate + "\nFee:" + Fee + "\nMinimum Rent for a day:" + MinRentOfDay +
                "\nConsulting Doctor:" + ConsultingDoctor;
        }

        public OutPatient(string name, int id, DateTime dob, string address, string doctor, int rno, DateTime disDate, double pFee, double pMinRent, string consDoc)
        {
            PatientName = name;
            PatIDStore = id;
            AdmitDate = DateTime.Now;
            PatientDOB = dob;
            PatientAge = AdmitDate.Year - PatientDOB.Year;
            PatientAddress = address;
            ReferringDoctor = doctor;
            RoomNo = rno;
            DischargeDate = disDate;
            Fee = pFee;
            MinRentOfDay = pMinRent;
            ConsultingDoctor = consDoc;
        }

        public override void GetPatientDetails()
        {
            int flag = 0;
            Console.WriteLine("Enter the Patient ID:");
            int idForDetails = Convert.ToInt32(Console.ReadLine());
            foreach (OutPatient outP in outPatientList)
            {
                if (outP.PatIDStore == idForDetails)
                {
                    Console.WriteLine(outP);
                    flag = 1;
                    break;
                }
            }
            if (flag == 0)
            {
                Console.WriteLine("Not a valid patient id!");
            }

        }

        public override void AddPatientDetails()
        {

            try
            {
                Console.WriteLine("Enter the patient's name:");
                string pName = Console.ReadLine();
                Console.WriteLine("Enter the date of birth: ");
                DateTime pDob = Convert.ToDateTime(Console.ReadLine());
                Console.WriteLine("Enter the address");
                string pAddress = Console.ReadLine();
                Console.WriteLine("Enter the refering doctor name: ");
                string pRefDoc = Console.ReadLine();
                Console.WriteLine("Enter the Room No:");
                int room = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Enter the discharge date: ");
                DateTime pdisdate = Convert.ToDateTime(Console.ReadLine());
                Console.WriteLine("Enter the Fee");
                double fee = Convert.ToDouble(Console.ReadLine());
                Console.WriteLine("enter the admission date");
                AdmitDate = Convert.ToDateTime(Console.ReadLine());
                Console.WriteLine("Enter the minimum rent of the day");
                double rent = Convert.ToDouble(Console.ReadLine());

                Console.WriteLine("Enter consulting doctor's name:");
                string pConsDoc = Console.ReadLine();

                int pID = ++PatientId;

                outPatientList.Add(new OutPatient(pName, pID, pDob, pAddress, pRefDoc, room, pdisdate, fee, rent, pConsDoc));
                Console.WriteLine("Patient details successfully saved with Id:{0}", pID);
            }
            catch
            {
                Console.WriteLine("Enter in mm/dd/yyyy format!");
            }
        }

        public override void RemovePatient()
        {
            int count = 0; int flag = 0;
            Console.WriteLine("Enter patient id:");
            int id = Convert.ToInt32(Console.ReadLine());
            foreach (OutPatient o in outPatientList)
            {
                if (o.PatientId == id)
                {
                    outPatientList.RemoveAt(count);
                    flag = 1;
                    Console.WriteLine("Details removed");
                    break;
                }
                count++;
            }
            if (flag == 0)
            {
                Console.WriteLine("Enter valid id!");
            }
        }
        public void GetBill()
        {
            int count = 0; int flag = 0;
            Console.WriteLine("Enter patient id:");
            int id = Convert.ToInt32(Console.ReadLine());
            foreach (OutPatient o in outPatientList)
            {
                if (o.PatientId == id)
                {
                    double consultationFee = o.Fee;
                    double roomRentPerDay = o.MinRentOfDay;
                    int noOfDaysStayed = o.AdmitDate.Day - o.DischargeDate.Day;
                    double totalBill = consultationFee + (roomRentPerDay * noOfDaysStayed);
                    flag = 1;
                    Console.WriteLine("Total Bill Amount:Rs.{0}", totalBill);
                    break;
                }
                count++;
            }
            if (flag == 0)
            {
                Console.WriteLine("Enter valid id!");
            }

        }
    }
}