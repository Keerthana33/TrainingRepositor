﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ticketbook
{
    public class Admin
    {
        internal void Start(List<Order> PassedOrderList, List<Customer> PassedCustomerList, List<Transaction> PassedTransactionList, List<Ticket> PassedTicketList)
        {
            Console.WriteLine("\n Welcome ADMIN \n");
            int whilechoice = 0;
            do
            {
                Console.WriteLine("\nEnter 1.View orders\n 2.View all customers\n 3. View ticket list\n");
                int choice = Convert.ToInt32(Console.ReadLine());
                Ticket tic = new Ticket();
                switch (choice)
                {
                    case 1:
                        Order O = new Order();
                        O.Getorders(PassedOrderList, PassedTransactionList);
                        break;
                    case 2:
                        Customer C = new Customer();
                        C.Getalldetails(PassedCustomerList);
                        break;
                    case 3:
                        tic.ticketdetails(PassedTicketList);
                        break;
                    
                    default:
                        new ChoiceException();
                        break;
                }
               
                       Console.WriteLine("\n\nEnter 1 for another transaction \n other to abort");
                       whilechoice = Convert.ToInt32(Console.ReadLine());
            } 
            
                      while (whilechoice == 1);
                      Console.WriteLine("\nSuccessfully Logged out\n");
        }
    }
}
