﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _496526
{
    //interface InvoicedItem
    //{
    //    int price;
    //    int discount;
    //    int warranty;.
    //    int xchangeperiod;
    //}
    interface iitem
    {

        void Getdiscount(int ICode);

        void GetPrice(int ICode);

        void GetXChangePeriod();

    }

    public class Item
    {
        public string productcode { get; set; }
        public int itemcode { get; set; }
        public string weight { get; set; }
        public int uom { get; set; }

        public void AddItem()
        {
            Console.WriteLine("add new item");
            itemcode = Convert.ToInt32(Console.ReadLine());
        }
        public void RemoveItem(Item i)
        {
            i.productcode = null;
            i.itemcode = 0;
        }
        public void convert()
        {
            Console.WriteLine("enter the weight of the items in liters");
            uom = Convert.ToInt32(Console.ReadLine());
            double scalingfactor = 1.1;
            double wt = uom / scalingfactor;
            Console.WriteLine("weight after conversion is:{0}", wt);
        }

    }
    public class InvoicedItem : Item
    {

        public int price { get; set; }
        public int discount { get; set; }
        public int warranty { get; set; }
        public int Xchangeperiod { get; set; }

        public int price1;
        public InvoicedItem()
        {
            Console.WriteLine("enter the price of the product ");
            price = Convert.ToInt32(Console.ReadLine());
            if (price > 0)
            {
                Console.WriteLine("enter the discount for the product ");
                discount = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("enter the warranty for the product ");
                warranty = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("enter the period for exchanging the product ");
                Xchangeperiod = Convert.ToInt32(Console.ReadLine());
            }
            else
                Console.WriteLine("enter the price of the product ");
            price = Convert.ToInt32(Console.ReadLine());
        }
        public void AddItem(Item c)
        {
            Console.WriteLine("add new item");
            c.itemcode = Convert.ToInt32(Console.ReadLine());

        }
        public void RemoveItem(Item i)
        {
            i.productcode = null;
            i.itemcode = 0;
        }
        public void calculatediscount()
        {
            int price1;
            price1 = price - (price * discount / 100);
            Console.WriteLine("After discount the price is:{0}", price1);

        }
    }
    class invoice
    {
        public string productcode;
        public int quantity;
        public float amount;
        InvoicedItem a = new InvoicedItem();
        Item i = new Item();
        public void generatebill()
        {
            Console.WriteLine("The itemcode of the product is:", i.itemcode);
            Console.WriteLine("The price of the product is:", a.price);
            Console.WriteLine("The price of the product after discount is:", a.price1);

        }
    }

    class exceptionitemcode : ApplicationException
    {

        public string Message
        {
            get
            {
                return "itemcode is not matched";
            }
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            Item i = new Item();
            InvoicedItem a = new InvoicedItem();
            List<InvoicedItem> li = new List<InvoicedItem>();
            li.Add(a);
            invoice d = new invoice();

            Console.WriteLine("choose your preferred option \n1.Add new item \n2.Remove an item \n3.Calculate discount \n4.generate a bill \n5.exit");
            int ch = Convert.ToInt16(Console.ReadLine());
            switch (ch)
            {
                case 1:
                    i.AddItem();
                    break;
                case 2:
                    i.RemoveItem(i);
                    break;
                case 3:
                    a.calculatediscount();
                    break;
                case 4:
                    d.generatebill();
                    break;
                case 5:
                    break;
                Default:
                    Console.WriteLine("invalid choice");
                    break;


            }
            try
            {
                if (i.itemcode != Convert.ToInt32(i.productcode))

                    throw (new exceptionitemcode());
            }
            catch (exceptionitemcode e)
            {
                Console.WriteLine(e.Message);
            }
        }

    }
}

