﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _495077_Vehicledealer
{
    class Vehicle
    {
        public string name { get; set; }
        public int id { get; set; }
        public int noofmodels{ get; set; }

        public override string ToString()
        {
            return id.ToString() + "\t" + name.ToString() + "\t" + noofmodels.ToString();
        }
    }
    interface IVAT
    {

        void calculate_VAT(List<Model> a);

    }

    class Model : Vehicle, IVAT
    {

        
        //static readonly long id = 1000;
        public int i = 1;
         public int id;
         public string type;
         public string model;
        public double price { get; set; }
        public Boolean inStock { get; set; }
        public override string ToString()
        {
            return id.ToString() + "\t" + model.ToString() +"\t" + price.ToString() +
                "\t" + inStock.ToString();
        }
        public void Add_model(List<Model> a)
        {
            Model m=new Model();
            Console.WriteLine("Enter type,model, price");
            m.type = Convert.ToString(Console.ReadLine());
            m.model = Convert.ToString(Console.ReadLine());
           
            m.price = Convert.ToDouble(Console.ReadLine());
            a.Add(m);

            Console.WriteLine("Model inserted successfully");


        }
        public void delete_model(List<Model> vehicle)
        {
            int id;
            int count = 0; int j = 0;

            Console.Write("Enter model number: ");
            id = Convert.ToInt32(Console.ReadLine());

            foreach (Model m in vehicle)
            {
                if (m.id == id)
                {

                    vehicle.RemoveAt(count);
                    Console.WriteLine("model was deleted");
                    j++;
                    break;

                }
                count++;

            }
            if (j == 0)
            {
                Console.WriteLine("No model exist with that id");
            }

        }
        public void display_allmodels(List<Model> a)
        {
            foreach (Model m in a)
            {
                Console.WriteLine(m.ToString());
            }
        }
        public void modify_price(List<Model> a)
        {
            int newprice;
            int id;
            int count = 0;

            Console.Write("Enter id: ");
            id = Convert.ToInt32(Console.ReadLine());
            try
            {
                foreach (Model m in a)
                {
                    if (m.id == id)
                    {
                        Console.Write("Enter New Price: ");
                        newprice = Convert.ToInt32(Console.ReadLine());
                        m.price = newprice;
                        count++;
                    }

                }
                if (count == 0)
                {
                    throw (new Nomodel());

                }
            }
            catch (Nomodel ex)
            {
                Console.WriteLine(ex.msg2());
            }
        }

        public void display_1model(List<Model> a)
        {
            Console.WriteLine("Enter modelnumber");
            int au = Convert.ToInt16(Console.ReadLine());
            int count = 0;

            foreach (Model m in a)
            {
                if (m.id == au)
                {
                    Console.WriteLine("{0} {1} {2} {3}", m.id, m.model, m.price, m.inStock);
                    count++;
                }

            }
            if (count == 0)
            {
                Console.WriteLine("No such model");
            }
        }


        public void modelsInAPriceRange(List<Model> a)
        {
            double lower, upper;
            Console.WriteLine("enter the lower price in the range");
            lower = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("enter the upper price in the range");
            upper = Convert.ToDouble(Console.ReadLine());
            int flag = 0;

            foreach (Model y in a)
            {
                if (y.price > lower && y.price < upper)
                {
                    flag = 1;
                    Console.WriteLine("The model details are");
                    Console.WriteLine("{0},{1},{2}", y.id, y.model, y.price);
                    break;

                }
            }
            if (flag == 0)
            {
                Console.WriteLine("No vehicles present in this range");
            }

        }
       
     
      
        public void check_available(List<Model> a)
        {
            int count = 0;
            try
            {
                Console.WriteLine("Enter id");
                int t = Convert.ToInt16(Console.ReadLine());
                foreach (Model m in a)
                {
                    if (m.id == t && m.inStock == true)
                    {
                        Console.WriteLine("Available");
                        count++;
                    }

                }
                if (count == 0)
                {

                    throw (new NotAvailable());

                }
            }
            catch (NotAvailable ex)
            {
                Console.WriteLine(ex.msg1());
            }
        }
        public void lowestPricedModel(List<Model> a)
        {
            double min = 100000000000;
            for (int i = 0; i < a.Count; i++)
            {
                if (a[i].price < min)
                {
                    min = a[i].price;
                }
            }

            Console.WriteLine("The lowest price is {0}", min);
        }

        public void calculate_VAT(List<Model> a)
        {
            int id;
            int count = 0;

            Console.Write("id: ");
            id = Convert.ToInt32(Console.ReadLine());
            foreach (Model m in a)
            {
                if (m.id == id)
                {
                    double VAT = 0.45 * m.price;
                    Console.WriteLine("VAT:Rs.{0}", VAT);
                    count++;
                }

            }
            if (count == 0)
                Console.WriteLine("No vehicles exist with that book number");


        }
        class Userdefinedexception : ApplicationException
        {
            public string msg()
            {
                return "enter correct details";
            }
        }
        class NotAvailable : ApplicationException
        {
            public string msg1()
            {
                return "Not Available";
            }
        }
        class Nomodel : ApplicationException
        {
            public string msg2()
            {
                return "No model found";
            }
        }
    }
    class program
    {
        static void Main(string[] args)
        {
            List<Vehicle> vehicle = new List<Vehicle>() {new Vehicle() {id=1,name="car",noofmodels=2},
            new Vehicle()  {id=2,name="van",noofmodels=2}, 
            new Vehicle()  {id=3,name="stationwagon",noofmodels=2}};
            foreach (Vehicle v1 in vehicle)
            {
                Console.WriteLine(v1.ToString());
            }
            List<Model> a = new List<Model>()
               {new Model() {id= 01, model="audi",price=2500000 ,inStock=true},
                new Model() {id= 02, model="bmw",price=2300000 ,inStock=true},
                new Model() {id= 03, model="jaguar",price=2200000 ,inStock=true},
                new Model() {id= 04, model="Rolls Royce",price=2550000 ,inStock=true},
                new Model() {id= 05, model="swift",price=2600000 ,inStock=true},

                new Model() {id= 06, model="van1",price=3500000 ,inStock=true},
                new Model() {id= 07, model="van2",price=2580000 ,inStock=true},
                new Model() {id= 08, model="van3",price=2900000 ,inStock=true},
                new Model() {id= 09, model="van4",price=3100000 ,inStock=true},
                new Model() {id= 10, model="van5",price=3567000 ,inStock=true},

                new Model() {id= 11, model="sw1",price=400000 ,inStock=true},
                new Model() {id= 12, model="sw2",price=4500000 ,inStock=true},
                new Model() {id= 13, model="sw3",price=36800000 ,inStock=true},
                new Model() {id= 14, model="sw4",price=460000 ,inStock=true},
                new Model() {id= 15, model="sw5",price=4200000 ,inStock=true}};

           Model b = new Model();
            foreach (Model b1 in a)
            {
                Console.WriteLine(b1.ToString());
            }
            while (true)
            {
                Console.WriteLine("\t*******Best Vehicle Dealers********");
                Console.WriteLine("\t Select your option:");
                Console.WriteLine("**********************************");
                Console.WriteLine(" 1:Add Model\n 2:Delete Model\n 3:Display all Models\n 4:modify the price of a Model\n 5:Search by Modelno\n6:Check Availability\n 7:calculate VAT\n8:PriceRange\n9.Lowest Priced Model\n10.Exit");
                Console.WriteLine("**********************************");
                int i = Convert.ToInt16(Console.ReadLine());


                switch (i)
                {
                    case 1:
                        b.Add_model(a);
                        break;
                    case 2:
                        b.delete_model(a);
                        break;
                    case 3:
                        b.display_allmodels(a);
                        break;
                    case 4:
                        b.modify_price(a);
                        break;
                    case 5:
                        b.display_1model(a);
                        break;
                   
                    case 6:
                        b.check_available(a);
                        break;
                    case 7:
                        b.calculate_VAT(a);
                        break;      
                    case 8:
                        b.modelsInAPriceRange(a);
                        break;
                    case 9:
                        b.lowestPricedModel(a);
                        break;
                    case 10:
                        break;





                }
                Console.WriteLine("If you want to exit press y and if not press n");
                Char e = Convert.ToChar(Console.ReadLine());
                if (e.Equals('y') || e.Equals('Y'))
                {
                    break;
                }
                else
                {
                    continue;
                }

            }
        }
    }
}
