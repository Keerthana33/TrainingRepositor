﻿using System;
using System.Collections.Generic;
using System.Linq;


namespace Applicationforproduct
{
    public class Product
    {
        string ProductName;
        static int? productId = null;
        int noofmodels;
        public string productName
        {
            get { return ProductName; }

            set { ProductName = value; }
        }
        public int ProductId
        {
            get
            {
                return ProductId;
                if (productId >= 1)
                {
                    Console.WriteLine("id is not valid");
                }
            }
            set { ProductId = value; }
        }
    }

    interface IVatCalculation
    {
        double CalculateVAT(double price);

    }

    class Model : Product, IVatCalculation
    {

        double Vat;

        public string ans;

        public int ItemModelId;

        public string ModelName;

        public double ModelPrice;

        public bool InStock;

        public Model()
        { }

        public double CalculateVAT(double price)
        {
            return (4 * price) / 100;
        }
        public override string ToString()
        {

            return "\nItem Model Id: " + ItemModelId.ToString() +
                    "\nModel Name: " + ModelName + "\nModel Price: " + ModelPrice.ToString() + "\tVAT: " + Vat.ToString() + "\tTotal: " + (ModelPrice + Vat).ToString() + "\nIn Stock: " + InStock;
        }
        public Model(int modelId, string modelName)
        {
            this.ItemModelId = modelId;
            this.ModelName = modelName;
        }
        public Model(double modPrice, bool modInStock)
        {
            this.ModelPrice = modPrice;
            this.InStock = modInStock;
        }
        List<Model> MobileList = new List<Model>();
        List<Model> IpodList = new List<Model>();
        List<Model> GameBoxList = new List<Model>();

        public void AddModel(int c)
        {
            Model m = new Model();


            while (true)
            {
                Console.WriteLine("Enter Item Model Id :");
                try
                {
                    int x = Convert.ToInt32(Console.ReadLine());
                    if (x > 0)
                    {
                        m.ItemModelId = x;
                    }
                    else
                    {
                        throw new ModelIdException();
                    }
                    break;
                }
                catch (ModelIdException exp)
                {
                    Console.WriteLine(exp.Message1);
                }
                catch (Exception)
                {
                    Console.WriteLine("Enter Valid Exception :");
                }
            }

            Console.WriteLine("Enter the Model Name :");

            m.ModelName = Console.ReadLine();
            Console.WriteLine("Enter The Model Price :");
            while (true)
            {
                try
                {
                    m.ModelPrice = Convert.ToDouble(Console.ReadLine());
                    break;
                }
                catch (Exception)
                {
                    Console.WriteLine(" Enter the valid input :");
                }
            }

            m.Vat = CalculateVAT(m.ModelPrice);

            Console.WriteLine(" Instock ? Yes/No");
            ans = Console.ReadLine();
            if (ans == "y")
            {
                m.InStock = true;
            }
            else
            {
                m.InStock = false;
            }
            if (c == 1)
            {
                MobileList.Add(m);
            }
            if (c == 2)
            {
                IpodList.Add(m);
            }
            if (c == 3)
            {
                GameBoxList.Add(m);
            }

        }

        public void DeleteModel(int c)
        {

            try
            {
                if (c == 1)
                {
                    if (MobileList.Count == 0)
                    {
                        throw (new NoModelsException());
                    }
                    int count = 0, flag = 0;
                    Console.WriteLine("Enter model id:");
                    int mId = Convert.ToInt32(Console.ReadLine());
                    foreach (Model m in MobileList)
                    {
                        if (m.ItemModelId == mId)
                        {
                            MobileList.RemoveAt(count);
                            Console.WriteLine("Model with model id {0} is successfully removed!", mId);
                            flag = 1;
                            break;
                        }
                        count++;
                    }
                    if (flag == 0)
                    {
                        throw (new ModelIdException(mId));
                    }
                }
                if (c == 2)
                {
                    if (IpodList.Count == 0)
                    {
                        throw (new NoModelsException());
                    }
                    int count = 0, flag = 0;
                    Console.WriteLine("Enter model id:");
                    int mId = Convert.ToInt32(Console.ReadLine());
                    foreach (Model m in IpodList)
                    {
                        if (m.ItemModelId == mId)
                        {
                            IpodList.RemoveAt(count);
                            Console.WriteLine("Model with model id {0} is successfully removed!", mId);
                            flag = 1;
                            break;
                        }
                        count++;
                    }
                    if (flag == 0)
                    {
                        throw (new ModelIdException(mId));
                    }
                }
                if (c == 3)
                {
                    if (GameBoxList.Count == 0)
                    {
                        throw (new NoModelsException());
                    }
                    int count = 0, flag = 0;
                    Console.WriteLine("Enter model id:");
                    int mId = Convert.ToInt32(Console.ReadLine());
                    foreach (Model m in GameBoxList)
                    {
                        if (m.ItemModelId == mId)
                        {
                            GameBoxList.RemoveAt(count);
                            Console.WriteLine("Model with model id {0} is successfully removed!", mId);
                            flag = 1;
                            break;
                        }
                        count++;
                    }
                    if (flag == 0)
                    {
                        throw (new ModelIdException(mId));
                    }
                }
            }

            catch (NoModelsException exp)
            {
                Console.WriteLine("\n---------------------------------\n");
                Console.WriteLine(exp.Message1);
                Console.WriteLine("\n---------------------------------\n");
            }
            catch (ModelIdException exp)
            {
                Console.WriteLine("\n---------------------------------\n");
                Console.WriteLine(exp.Message1);
                Console.WriteLine("\n---------------------------------\n");
            }
        }


        public void DisplayAllModels(int c)
        {

            try
            {
                if (c == 1)
                {

                    if (MobileList.Count == 0)
                    {
                        throw (new NoModelsException());
                    }
                    else
                    {
                        foreach (Model m in MobileList)
                        {

                            Console.WriteLine("\n---------------------------------\n");
                            Console.WriteLine(m.ToString());
                            Console.WriteLine("\n---------------------------------\n");

                        }
                    }
                }
                if (c == 2)
                {
                    if (IpodList.Count == 0)
                    {
                        throw (new NoModelsException());
                    }
                    else
                    {
                        foreach (Model m in IpodList)
                        {
                            Console.WriteLine("\n---------------------------------\n");
                            Console.WriteLine(m.ToString());
                            Console.WriteLine("\n---------------------------------\n");

                        }
                    }
                }
                if (c == 3)
                {
                    if (GameBoxList.Count == 0)
                    {
                        throw (new NoModelsException());
                    }
                    else
                    {
                        foreach (Model m in GameBoxList)
                        {
                            Console.WriteLine("\n---------------------------------\n");
                            Console.WriteLine(m.ToString());
                            Console.WriteLine("\n---------------------------------\n");

                        }
                    }
                }
            }
            catch (NoModelsException exp)
            {
                Console.WriteLine("\n---------------------------------\n");
                Console.WriteLine(exp.Message1);
                Console.WriteLine("\n---------------------------------\n");
            }
        }

        public void ModifyPrice(int c)
        {
            try
            {
                if (c == 1)
                {
                    if (MobileList.Count == 0)
                    {
                        throw (new NoModelsException());
                    }
                    int count = 0, flag = 0;
                    Console.WriteLine("Enter model id:");
                    int mId = Convert.ToInt32(Console.ReadLine());
                    foreach (Model m in MobileList)
                    {
                        if (m.ItemModelId == mId)
                        {
                            Console.WriteLine("Enter new price:");
                            double p = Convert.ToDouble(Console.ReadLine());
                            m.ModelPrice = p;
                            Console.WriteLine("Price for model id {0} is successfully updated!", mId);
                            flag = 1;
                            break;
                        }
                        count++;
                    }
                    if (flag == 0)
                    {
                        throw (new ModelIdException(mId));
                    }
                }
                if (c == 2)
                {
                    if (IpodList.Count == 0)
                    {
                        throw (new NoModelsException());
                    }
                    int count = 0, flag = 0;
                    Console.WriteLine("Enter model id:");
                    int mId = Convert.ToInt32(Console.ReadLine());
                    foreach (Model m in IpodList)
                    {
                        if (m.ItemModelId == mId)
                        {
                            Console.WriteLine("Enter new price:");
                            double p = Convert.ToDouble(Console.ReadLine());
                            m.ModelPrice = p;
                            Console.WriteLine("Price for model id {0} is successfully updated!", mId);
                            flag = 1;
                            break;
                        }
                        count++;
                    }
                    if (flag == 0)
                    {
                        throw (new ModelIdException(mId));
                    }
                }
                if (c == 3)
                {
                    if (GameBoxList.Count == 0)
                    {
                        throw (new NoModelsException());
                    }
                    int count = 0, flag = 0;
                    Console.WriteLine("Enter model id:");
                    int mId = Convert.ToInt32(Console.ReadLine());
                    foreach (Model m in GameBoxList)
                    {
                        if (m.ItemModelId == mId)
                        {
                            Console.WriteLine("Enter new price:");
                            double p = Convert.ToDouble(Console.ReadLine());
                            m.ModelPrice = p;
                            Console.WriteLine("Price for model id {0} is successfully updated!", mId);
                            flag = 1;
                            break;
                        }
                        count++;
                    }
                    if (flag == 0)
                    {
                        throw (new ModelIdException(mId));
                    }
                }
            }
            catch (NoModelsException exp)
            {
                Console.WriteLine("\n---------------------------------\n");
                Console.WriteLine(exp.Message1);
                Console.WriteLine("\n---------------------------------\n");
            }
            catch (ModelIdException exp)
            {
                Console.WriteLine("\n---------------------------------\n");
                Console.WriteLine(exp.Message1);
                Console.WriteLine("\n---------------------------------\n");
            }
        }

        public void LowestPricedModel(int c)
        {
            try
            {
                if (c == 1)
                {
                    if (MobileList.Count == 0)
                    {
                        throw (new NoModelsException());
                    }
                    double temp;


                    temp = MobileList.First().ModelPrice;
                    for (int i = 1; i < MobileList.Count(); i++)
                    {
                        if (MobileList.ElementAt(i).ModelPrice < temp)
                        {
                            temp = MobileList.ElementAt(i).ModelPrice;
                        }
                    }
                    foreach (Model m in MobileList)
                    {
                        if (m.ModelPrice == temp)
                        {


                            Console.WriteLine("\n---------------------------------\n");

                            Console.WriteLine(m.ToString());
                            Console.WriteLine("\n---------------------------------\n");
                        }
                    }
                }
                if (c == 2)
                {
                    if (IpodList.Count == 0)
                    {
                        throw (new NoModelsException());
                    }
                    double temp;


                    temp = IpodList.First().ModelPrice;
                    for (int i = 1; i < IpodList.Count(); i++)
                    {
                        if (IpodList.ElementAt(i).ModelPrice < temp)
                        {
                            temp = MobileList.ElementAt(i).ModelPrice;
                        }
                    }
                    foreach (Model m in IpodList)
                    {
                        if (m.ModelPrice == temp)
                        {


                            Console.WriteLine("\n---------------------------------\n");

                            Console.WriteLine(m.ToString());
                            Console.WriteLine("\n---------------------------------\n");
                        }
                    }
                }
                if (c == 3)
                {
                    if (GameBoxList.Count == 0)
                    {
                        throw (new NoModelsException());
                    }
                    double temp;


                    temp = GameBoxList.First().ModelPrice;
                    for (int i = 1; i < GameBoxList.Count(); i++)
                    {
                        if (GameBoxList.ElementAt(i).ModelPrice < temp)
                        {
                            temp = GameBoxList.ElementAt(i).ModelPrice;
                        }
                    }
                    foreach (Model m in GameBoxList)
                    {
                        if (m.ModelPrice == temp)
                        {


                            Console.WriteLine("\n---------------------------------\n");

                            Console.WriteLine(m.ToString());
                            Console.WriteLine("\n---------------------------------\n");
                        }
                    }
                }
            }
            catch (NoModelsException exp)
            {
                Console.WriteLine("\n---------------------------------\n");
                Console.WriteLine(exp.Message1);
                Console.WriteLine("\n---------------------------------\n");
            }

        }

        public void ModelsInAPriceRange(int c)
        {
            try
            {
                if (c == 1)
                {
                    if (MobileList.Count == 0)
                    {
                        throw (new NoModelsException());
                    }

                    Console.WriteLine("Enter Start Price:");
                    double sp = Convert.ToDouble(Console.ReadLine());

                    Console.WriteLine("Enter End Price:");
                    double ep = Convert.ToDouble(Console.ReadLine());

                    foreach (Model m in MobileList)
                    {
                        if (m.ModelPrice >= sp && m.ModelPrice <= ep)
                        {
                            Console.WriteLine("\n---------------------------------\n");
                            Console.WriteLine("Model Name:\t{0} Price:\t{1}", m.ModelName, m.ModelPrice);
                            Console.WriteLine("\n---------------------------------\n");
                        }
                    }
                }
                if (c == 2)
                {
                    if (IpodList.Count == 0)
                    {
                        throw (new NoModelsException());
                    }

                    Console.WriteLine("Enter Start Price:");
                    double sp = Convert.ToDouble(Console.ReadLine());

                    Console.WriteLine("Enter End Price:");
                    double ep = Convert.ToDouble(Console.ReadLine());

                    foreach (Model m in IpodList)
                    {
                        if (m.ModelPrice >= sp && m.ModelPrice <= ep)
                        {
                            Console.WriteLine("\n---------------------------------\n");
                            Console.WriteLine("Model Name:\t{0} Price:\t{1}", m.ModelName, m.ModelPrice);
                            Console.WriteLine("\n---------------------------------\n");
                        }
                    }
                }
                if (c == 3)
                {
                    if (GameBoxList.Count == 0)
                    {
                        throw (new NoModelsException());
                    }

                    Console.WriteLine("Enter Start Price:");
                    double sp = Convert.ToDouble(Console.ReadLine());

                    Console.WriteLine("Enter End Price:");
                    double ep = Convert.ToDouble(Console.ReadLine());

                    foreach (Model m in GameBoxList)
                    {
                        if (m.ModelPrice >= sp && m.ModelPrice <= ep)
                        {
                            Console.WriteLine("\n---------------------------------\n");
                            Console.WriteLine("Model Name:\t{0} Price:\t{1}", m.ModelName, m.ModelPrice);
                            Console.WriteLine("\n---------------------------------\n");
                        }
                    }
                }
            }
            catch (NoModelsException exp)
            {
                Console.WriteLine("\n---------------------------------\n");
                Console.WriteLine(exp.Message1);
                Console.WriteLine("\n---------------------------------\n");

            }
        }


        public void DisplayOneModel(int c)
        {
            try
            {
                if (c == 1)
                {
                    if (MobileList.Count == 0)
                    {
                        throw (new NoModelsException());
                    }
                    Console.WriteLine("Enter model id:");
                    int id = Convert.ToInt32(Console.ReadLine());
                    foreach (Model m in MobileList)
                    {
                        Console.WriteLine(id);
                        if (m.ItemModelId == id)
                        {
                            Console.WriteLine("\n---------------------------------\n");
                            Console.WriteLine(m.ToString());
                            Console.WriteLine("\n---------------------------------\n");
                        }
                    }
                }
                if (c == 2)
                {
                    if (IpodList.Count == 0)
                    {
                        throw (new NoModelsException());
                    }
                    Console.WriteLine("Enter model id:");
                    int id = Convert.ToInt32(Console.ReadLine());
                    foreach (Model m in IpodList)
                    {
                        Console.WriteLine(id);
                        if (m.ItemModelId == id)
                        {
                            Console.WriteLine("\n---------------------------------\n");
                            Console.WriteLine(m.ToString());
                            Console.WriteLine("\n---------------------------------\n");
                        }
                    }
                }
                if (c == 3)
                {
                    if (GameBoxList.Count == 0)
                    {
                        throw (new NoModelsException());
                    }
                    Console.WriteLine("Enter model id:");
                    int id = Convert.ToInt32(Console.ReadLine());
                    foreach (Model m in GameBoxList)
                    {
                        Console.WriteLine(id);
                        if (m.ItemModelId == id)
                        {
                            Console.WriteLine("\n---------------------------------\n");
                            Console.WriteLine(m.ToString());
                            Console.WriteLine("\n---------------------------------\n");
                        }
                    }
                }
            }
            catch (NoModelsException exp)
            {
                Console.WriteLine("\n---------------------------------\n");
                Console.WriteLine(exp.Message1);
                Console.WriteLine("\n---------------------------------\n");

            }
        }

        public void CheckAvailable(int c)
        {
            try
            {
                if (c == 1)
                {
                    if (MobileList.Count == 0)
                    {
                        throw (new NoModelsException());
                    }
                    Console.WriteLine("Enter model id:");
                    int id = Convert.ToInt32(Console.ReadLine());
                    foreach (Model m in MobileList)
                    {
                        if (m.ItemModelId == id)
                        {
                            if (m.InStock == true)
                            {
                                Console.WriteLine("\n---------------------------------\n");
                                Console.WriteLine("\tAvailable!");
                                Console.WriteLine("\n---------------------------------\n");
                            }
                            else
                            {
                                Console.WriteLine("\n---------------------------------\n");
                                Console.WriteLine("\tNot Available!");
                                Console.WriteLine("\n---------------------------------\n");
                            }

                        }
                    }
                }
                if (c == 2)
                {
                    if (IpodList.Count == 0)
                    {
                        throw (new NoModelsException());
                    }
                    Console.WriteLine("Enter model id:");
                    int id = Convert.ToInt32(Console.ReadLine());
                    foreach (Model m in IpodList)
                    {
                        if (m.ItemModelId == id)
                        {
                            if (m.InStock == true)
                            {
                                Console.WriteLine("\n---------------------------------\n");
                                Console.WriteLine("\tAvailable!");
                                Console.WriteLine("\n---------------------------------\n");
                            }
                            else
                            {
                                Console.WriteLine("\n---------------------------------\n");
                                Console.WriteLine("\tNot Available!");
                                Console.WriteLine("\n---------------------------------\n");
                            }

                        }
                    }
                }
                if (c == 3)
                {
                    if (GameBoxList.Count == 0)
                    {
                        throw (new NoModelsException());
                    }
                    Console.WriteLine("Enter model id:");
                    int id = Convert.ToInt32(Console.ReadLine());
                    foreach (Model m in GameBoxList)
                    {
                        if (m.ItemModelId == id)
                        {
                            if (m.InStock == true)
                            {
                                Console.WriteLine("\n---------------------------------\n");
                                Console.WriteLine("\tAvailable!");
                                Console.WriteLine("\n---------------------------------\n");
                            }
                            else
                            {
                                Console.WriteLine("\n---------------------------------\n");
                                Console.WriteLine("\tNot Available!");
                                Console.WriteLine("\n---------------------------------\n");
                            }

                        }
                    }
                }
            }
            catch (NoModelsException exp)
            {
                Console.WriteLine("\n---------------------------------\n");
                Console.WriteLine(exp.Message1);
                Console.WriteLine("\n---------------------------------\n");

            }
        }

    }


    class ModelIdException : ApplicationException
    {
        string message1;
        public string Message1 { get { return message1; } set { message1 = value; } }

        string message2;
        public string Message2 { get { return message2; } set { message2 = value; } }

        public ModelIdException(int id)
            : base("Model Id Exception:")
        {
            Message1 = "Model with id " + id + " doesn't exist!";
        }

        public ModelIdException()
            : base("Model Id must be greater than zero.")
        {
            Message2 = "Model ID must be greater than zero.";
        }
    }


    class NoModelsException : ApplicationException
    {
        string msg0;
        public string Message1 { get { return msg0; } set { msg0 = value; } }
        public NoModelsException()
            : base("No Models Exception.")
        {
            Message1 = "There are no models added.";
        }
    }




    class Program
    {
        static void Main(string[] args)
        {
            Model m = new Model();


            int endMainLoop = 0;

            Console.WriteLine("---Application to keep track of products sold by a company---");

            while (endMainLoop == 0)
            {
                int choice;
                Console.WriteLine("\n---------------------------------------------\n");
                Console.WriteLine("1.Mobile     2.i-pod     3.Game-Box      4.Exit");
                Console.WriteLine("\n---------------------------------------------\n");
                while (true)
                {
                    try
                    {
                        choice = Convert.ToInt32(Console.ReadLine());
                        break;
                    }
                    catch (Exception)
                    {
                        Console.WriteLine("Enter valid choice.");
                    }
                }

                switch (choice)
                {
                    case 1:
                        int x = 0;
                        while (x == 0)
                        {
                            Console.WriteLine("\n------------------------------------------------------------------------\n");
                            Console.WriteLine("\n1. Add Model         2.Delete Model                3.Display All Models" +
                                "\n4.Modify Price       5.Lowest Priced Model         6.Models In A Price Range" +
                                "\n7.Display 1 Model    8.Check Availability Of Model 9.Exit");
                            Console.WriteLine("Selected Choice:");
                            Console.WriteLine("\n------------------------------------------------------------------------\n");

                            int ch;
                            while (true)
                            {
                                try
                                {
                                    ch = Convert.ToInt32(Console.ReadLine());
                                    break;
                                }
                                catch (Exception)
                                {
                                    Console.WriteLine("Enter valid choice.");
                                }
                            }
                            switch (ch)
                            {
                                case 1:
                                    m.AddModel(choice);


                                    break;
                                case 2:
                                    m.DeleteModel(choice);
                                    break;
                                case 3:
                                    m.DisplayAllModels(choice);
                                    break;
                                case 4:
                                    m.ModifyPrice(choice);
                                    break;
                                case 5:
                                    m.LowestPricedModel(choice);
                                    break;
                                case 6:
                                    m.ModelsInAPriceRange(choice);
                                    break;
                                case 7:
                                    m.DisplayOneModel(choice);
                                    break;
                                case 8:
                                    m.CheckAvailable(choice);
                                    break;
                                case 9:
                                    Console.WriteLine("EXIT");
                                    x = 1;
                                    break;
                                default:
                                    Console.WriteLine("Enter Valid Choice.");
                                    break;
                            }
                        }
                        break;
                    case 2:
                        int y = 1;
                        while (y == 1)
                        {
                            Console.WriteLine("\n------------------------------------------------------------------------\n");

                            Console.WriteLine("\n1. Add Model         2.Delete Model                3.Display All Models" +
                                    "\n4.Modify Price       5.Lowest Priced Model         6.Models In A Price Range" +
                                    "\n7.Display 1 Model    8.Check Availability Of Model 9.Exit");
                            Console.WriteLine("\n------------------------------------------------------------------------\n");

                            Console.WriteLine("Selected Choice:");

                            int ch;

                            while (true)
                            {
                                try
                                {
                                    ch = Convert.ToInt32(Console.ReadLine());
                                    break;
                                }
                                catch (Exception)
                                {
                                    Console.WriteLine("Enter valid choice.");
                                }
                            }
                            switch (ch)
                            {
                                case 1:
                                    m.AddModel(choice);


                                    break;
                                case 2:
                                    m.DeleteModel(choice);
                                    break;
                                case 3:
                                    m.DisplayAllModels(choice);
                                    break;
                                case 4:
                                    m.ModifyPrice(choice);
                                    break;
                                case 5:
                                    m.LowestPricedModel(choice);
                                    break;
                                case 6:
                                    m.ModelsInAPriceRange(choice);
                                    break;
                                case 7:
                                    m.DisplayOneModel(choice);
                                    break;
                                case 8:
                                    m.CheckAvailable(choice);
                                    break;
                                case 9:
                                    Console.WriteLine("EXIT");
                                    y = 1;
                                    break;
                                default:
                                    Console.WriteLine("Enter Valid Choice.");
                                    break;
                            }
                        }
                        break;
                    case 3:
                        int z = 0;
                        while (z == 0)
                        {
                            Console.WriteLine("\n------------------------------------------------------------------------\n");

                            Console.WriteLine("\n1. Add Model         2.Delete Model                3.Display All Models" +
                                    "\n4.Modify Price       5.Lowest Priced Model         6.Models In A Price Range" +
                                    "\n7.Display 1 Model    8.Check Availability Of Model 9.Exit");
                            Console.WriteLine("\n------------------------------------------------------------------------\n");

                            Console.WriteLine("Selected Choice:");
                            int ch = Convert.ToInt32(Console.ReadLine());
                            switch (ch)
                            {
                                case 1:
                                    m.AddModel(choice);
                                    break;
                                case 2:
                                    m.DeleteModel(choice);
                                    break;
                                case 3:
                                    m.DisplayAllModels(choice);
                                    break;
                                case 4:
                                    m.ModifyPrice(choice);
                                    break;
                                case 5:
                                    m.LowestPricedModel(choice);
                                    break;
                                case 6:
                                    m.ModelsInAPriceRange(choice);
                                    break;
                                case 7:
                                    m.DisplayOneModel(choice);
                                    break;
                                case 8:
                                    m.CheckAvailable(choice);
                                    break;
                                case 9:
                                    Console.WriteLine("EXIT");
                                    z = 1;
                                    break;
                                default:
                                    Console.WriteLine("Enter Valid Choice.");
                                    break;
                            }
                        }
                        break;
                    case 4:
                        endMainLoop = 1;
                        break;
                    default:
                        Console.WriteLine("Enter Valid Choice.");
                        break;
                }
            }
        }
    }
}
