﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LIC
{
    abstract class InsurancePolicyEssentials
    {
        public InsurancePolicyEssentials()
        {

        }

        public string PolicyName
        {
            get
            {
                return tmppolicyname;
            }
        }

        public string CustomerName;

        public int amount;

        public int years;

        public DateTime DateofInsurance;

        public DateTime MaturityDateofThePolicy;

        public int MaxCoverageLimit;

        public string tmppolicyname;

        public abstract void AddNewCustomer();


        public void RemoveCustomer(InsurancePolicyEssentials a)
        {
            a.CustomerName = null;
            a.amount = 0;

        }
        public void RemoveCustomer(InsurancePolicyEssentials b, int years)
        {
            b.CustomerName = null;
            b.amount = 0;
        }
        ~InsurancePolicyEssentials()
        {
            Console.WriteLine("Destructor is called");
        }

        public abstract void EditCustomerDetails();


        public virtual void GetPolicyDetails()
        {
            Console.WriteLine(PolicyName);
            Console.WriteLine(CustomerName);
            Console.WriteLine(DateofInsurance);
            Console.WriteLine(MaturityDateofThePolicy);
        }
    }

    interface IGetInstallmentDetails
    {
        void GetYearlyInstallmentDetails();
        void GetHalfYearlyInstallmentDetails();
        void MonthlyInstallmentDetails();
    }

    class InsuranceForIndividuals : InsurancePolicyEssentials, IGetInstallmentDetails
    {
        public int ROI { get; set; }

        public override void GetPolicyDetails()
        {

            Console.WriteLine(PolicyName);
            Console.WriteLine(CustomerName);
            Console.WriteLine(amount);
            Console.WriteLine(years);
            Console.WriteLine(DateofInsurance);
            Console.WriteLine(MaturityDateofThePolicy);
            Console.WriteLine(MaxCoverageLimit);

        }
        public override void AddNewCustomer()
        {

            Console.WriteLine("enter policy name");
            tmppolicyname = Console.ReadLine();
            Console.WriteLine("enter customer name");
            CustomerName = Console.ReadLine();
            Console.WriteLine("enter policy amount");
            amount = Convert.ToInt32(Console.ReadLine());
            years = 5;
            DateofInsurance = DateTime.Today;
            MaturityDateofThePolicy = DateTime.Today.AddYears(4);
            MaxCoverageLimit = 40000000;

        }
        public override void EditCustomerDetails()
        {
            Console.WriteLine("enter\n1.to change name of customer\n2.to change policy amount\n3.to change no.of plan years");
            int a = Convert.ToInt16(Console.ReadLine());
            switch (a)
            {
                case 1: Console.WriteLine("enter new name");
                    CustomerName = Console.ReadLine();
                    break;
                case 2: Console.WriteLine("enter new policy amount");
                    int c = Convert.ToInt32(Console.ReadLine());
                    if (c <= MaxCoverageLimit)
                        amount = c;
                    break;
                case 3: Console.WriteLine("enter new no .of years ");
                    years = Convert.ToInt32(Console.ReadLine());
                    break;
            }


        }
        public void ExtraFeatures()
        {
            Console.WriteLine("Rate of interest is 2 % per year");
            Console.WriteLine("maturity date is 4 years");
            Console.WriteLine("policy amount is Rs.500 only");

        }
        public void GetYearlyInstallmentDetails()
        {
            ROI = 2;
            double am;
            am = amount;
            am += am * 0.01;
            Console.WriteLine("yearly installment cost is " + am);
        }

        public void GetHalfYearlyInstallmentDetails()
        {
            ROI = 2;
            double am;
            am = amount / 6;
            am += am * 0.02;
            Console.WriteLine("half yearly installment cost is " + am);
        }
        public void MonthlyInstallmentDetails()
        {
            ROI = 2;
            double am;
            am = amount / 12;
            am += am * 0.02;
            Console.WriteLine("monthly installment cost is " + am);
        }
    }

    class InsuranceForFamily : InsurancePolicyEssentials, IGetInstallmentDetails
    {
        public int ROI { get; set; }

        public int NoOfPeopleCovered { get; set; }

        public int MaxNoOfPeopleCovered { get { return temp; } }

        int temp = 5;

        public override void AddNewCustomer()
        {
            Console.WriteLine("enter policy name");
            tmppolicyname = Console.ReadLine();
            Console.WriteLine("enter customer name");
            CustomerName = Console.ReadLine();
            Console.WriteLine("enter policy amount");
            amount = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("enter no of people to be covered");
            int a = Convert.ToInt16(Console.ReadLine());
            try
            {
                if (a >= MaxNoOfPeopleCovered)
                    throw (new MaxNoOfPepException());
                else
                    NoOfPeopleCovered = a;
            }
            catch (MaxNoOfPepException e)
            {
                Console.WriteLine(e.Message);
            }
            years = 3;
            DateofInsurance = DateTime.Today;
            MaturityDateofThePolicy = DateTime.Today.AddYears(4);
            MaxCoverageLimit = 60000000;

        }

        public override void GetPolicyDetails()
        {
            Console.WriteLine(PolicyName);
            Console.WriteLine(CustomerName);
            Console.WriteLine(amount);
            Console.WriteLine(years);
            Console.WriteLine(DateofInsurance);
            Console.WriteLine(MaturityDateofThePolicy);
            Console.WriteLine(MaxCoverageLimit);

        }
        public override void EditCustomerDetails()
        {
            Console.WriteLine("enter\n1.to change name of customer\n2.to change policy amount\n3.to change no.of plan years\n4.to change no of members");
            int a = Convert.ToInt16(Console.ReadLine());
            switch (a)
            {
                case 1: Console.WriteLine("enter new name");
                    CustomerName = Console.ReadLine();
                    break;
                case 2: Console.WriteLine("enter new policy amount");
                    int c = Convert.ToInt32(Console.ReadLine());
                    if (c <= MaxCoverageLimit)
                        amount = c;
                    break;
                case 3: Console.WriteLine("enter new no .of years ");
                    years = Convert.ToInt32(Console.ReadLine());
                    break;
                case 4: Console.WriteLine("enter no of people to be covered");
                    int a1 = Convert.ToInt16(Console.ReadLine());
                    try
                    {
                        if (a1 >= MaxNoOfPeopleCovered)
                            throw (new MaxNoOfPepException());
                        else
                            NoOfPeopleCovered = a1;
                    }
                    catch (MaxNoOfPepException e)
                    {
                        Console.WriteLine(e.Message);
                    }
                    break;
            }
        }
        public void ExtraFeatures()
        {
            Console.WriteLine("Rate of interest is 3 % per year for another policy by one of the family member");
            Console.WriteLine("maturity date can be extended to another  3 years");
            Console.WriteLine("policy amount is Rs.1000 only");
        }

        public void GetYearlyInstallmentDetails()
        {
            ROI = 2;
            double am;
            am = amount;
            am += am * 0.01;
            Console.WriteLine("yearly installment cost is " + am);
        }

        public void GetHalfYearlyInstallmentDetails()
        {
            ROI = 2;
            double am;
            am = amount / 6;
            am += am * 0.02;
            Console.WriteLine("half yearly installment cost is " + am);
        }
        public void MonthlyInstallmentDetails()
        {
            ROI = 2;
            double am;
            am = amount / 12;
            am += am * 0.02;
            Console.WriteLine("monthly installment cost is " + am);
        }
    }

    class MaxNoOfPepException : ApplicationException
    {

        public override string Message
        {
            get
            {
                return " MaxNoOfPeopleCovered Exception";
            }
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            List<InsurancePolicyEssentials> pi = new List<InsurancePolicyEssentials>();

            InsuranceForIndividuals i = new InsuranceForIndividuals();
            InsuranceForFamily IF = new InsuranceForFamily();
            while (true)
            {
                Console.WriteLine("1.Insurance forIndividual\n2.Insurance for Family\n3.Exit");
                int a = Convert.ToInt16(Console.ReadLine());
                switch (a)
                {

                    case 1: Console.WriteLine("1.To Add new Customer\n2.To Edit Customer Details\n3.To get Policy Details\n4.To remove Customer");
                        int b = Convert.ToInt16(Console.ReadLine());
                        switch (b)
                        {
                            case 1: i.AddNewCustomer();
                                pi.Add(i);
                                break;
                            case 2: i.EditCustomerDetails();
                                break;
                            case 3: foreach (InsuranceForIndividuals i1 in pi)
                                {
                                    Console.WriteLine("enter customer name");
                                    string nam = Console.ReadLine();
                                    if (i.CustomerName.Equals(nam))
                                    {
                                        i.GetPolicyDetails();
                                        i.GetYearlyInstallmentDetails();
                                        i.GetHalfYearlyInstallmentDetails();
                                        i.MonthlyInstallmentDetails();
                                    }
                                    else
                                    {
                                        Console.WriteLine("no customer name found");
                                        Console.WriteLine("enter y to add new customer or n to exit");
                                        char n = Convert.ToChar(Console.ReadLine());
                                        if (n.Equals('y') || n.Equals('Y'))
                                            i.AddNewCustomer();
                                        else
                                            break;
                                    }
                                }
                                break;
                            case 4: if ((i.MaturityDateofThePolicy.Year - DateTime.Today.Year) != 0)
                                    i.RemoveCustomer(i, i.years);
                                else
                                    i.RemoveCustomer(i);
                                break;
                        }
                        break;
                    case 2: Console.WriteLine("1.To Add new Customer\n2.To Edit Customer Details\n3.To get Policy Details\n4.To remove Customer");
                        int c = Convert.ToInt16(Console.ReadLine());
                        switch (c)
                        {
                            case 1: IF.AddNewCustomer();
                                pi.Add(i);
                                break;
                            case 2: IF.EditCustomerDetails();
                                break;
                            case 3:
                                foreach (InsuranceForFamily i1 in pi)
                                {
                                    Console.WriteLine("enter customer name");
                                    string nam = Console.ReadLine();
                                    if (IF.CustomerName.Equals(nam))
                                    {

                                        IF.GetPolicyDetails();
                                        IF.GetYearlyInstallmentDetails();
                                        IF.GetHalfYearlyInstallmentDetails();
                                        IF.MonthlyInstallmentDetails();
                                    }
                                    else
                                    {
                                        Console.WriteLine("no customer name found");
                                        Console.WriteLine("enter y to add new customer or n to exit");
                                        char n = Convert.ToChar(Console.ReadLine());
                                        if (n.Equals('y') || n.Equals('Y'))
                                            IF.AddNewCustomer();
                                        else
                                            break;
                                    }

                                }
                                break;
                            case 4: if ((IF.MaturityDateofThePolicy.Year - DateTime.Today.Year) != 0)
                                    IF.RemoveCustomer(IF, IF.years);
                                else
                                    IF.RemoveCustomer(IF);
                                break;
                        }
                        break;
                    case 3: break;
                }
                Console.WriteLine("enter y to continue or n to exit");
                char n1 = Convert.ToChar(Console.ReadLine());
                if (n1.Equals('y') || n1.Equals('Y'))
                    continue;
                else
                    break;
            }
        }
    }
}


