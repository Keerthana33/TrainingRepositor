﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace _496293_Flight
{
    sealed class Commercial_Flight : Flight, iFlight
    {
        public static int flightnumber = 202020;
        
        public Commercial_Flight()
        {
        }
        public Commercial_Flight(string type, int flightnumber, int availableSeats, string source, string destination, float speed, int distance, DateTime time)
        {
            this.FlightNo = flightnumber;
            this.Type = type;
            AvailableSeats = availableSeats;
            Source = source;
            Destination = destination;
            Speed = speed;
            Distance = distance;
            StartTime = time;
        }
        private int availableseats;
        private string source;
        private string destination;
        
        public int AvailableSeats
        {
            get { return availableseats; }
            set { availableseats = value; }
        }
        public string Destination
        {
            get { return destination; }
            set { destination = value; }
        }
        public string Source
        {
            get { return source; }
            set { source = value; }
        }
        public override string ToString()
        {
            return "\nFlight Type:" + Type + "\nflightnumberumber:" + FlightNo + "\nAvailable Seats:" + AvailableSeats + "\nSource:" + Source + "\nDestination:" + Destination + "\nStart Time:" + StartTime + "\nDistance in kms:" + Distance;
        }
        List<Commercial_Flight> commflight = new List<Commercial_Flight>();
        public int temp = 0;
        public override void AddFlight(string flighttype)
        {
            try
            {
                Console.WriteLine("Enter Seating Capacity");
                int available = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Enter Distance to be travelled");
                int distance = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Enter Speed in kmph");
                float speed = Convert.ToSingle(Console.ReadLine());
                Console.WriteLine("Enter Source");
                string source = Console.ReadLine();
                if (source=="")
                {
                    throw new EmptyString();
                }
                Console.WriteLine("Enter Destination  ");
                string destination = Console.ReadLine();
                if (destination == "")
                {
                    throw new EmptyString();
                }
                Console.WriteLine("Enter start time");
                DateTime time = Convert.ToDateTime(Console.ReadLine());
                Commercial_Flight cmf = new Commercial_Flight(flighttype, flightnumber++, available, source, destination, speed, distance, time);
                commflight.Add(cmf);
                Console.WriteLine("\nFlight details added successfully");
                Console.WriteLine(cmf+"\n");
            }
            catch (InvalidDetailsException e)
            {
                Console.WriteLine(e.Message);
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
        }
        public override void RemoveFlight()
        {
            try
            {
                Console.WriteLine("Enter the Flight Number: ");
                int flightno = Convert.ToInt32(Console.ReadLine());
                
                int i = 0;
                foreach (Commercial_Flight c in commflight)
                {
                    if (c.FlightNo == flightno)
                    {
                        commflight.RemoveAt(i);
                        Console.WriteLine("Flight removed successfully\n");
                        temp++;
                        break;
                    }
                    i++;
                }
                if (temp == 0)
                {
                    throw new FlightNotFoundException();
                }
            }
            catch (FlightNotFoundException e)
            {
                Console.WriteLine(e.Message);
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
        }
        public override void CalculateDuration()
        {
            try
            {
                
                Console.WriteLine("Enter Flight Number: ");
                int fn = Convert.ToInt32(Console.ReadLine());
                foreach (Commercial_Flight c in commflight)
                {
                    if (c.FlightNo == fn)
                    {
                        float duration = (c.Distance / c.Speed) * 60;
                        Console.WriteLine(duration + " mins");
                        temp++;
                        break;
                    }
                }
                if (temp == 0)
                {
                    throw new FlightNotFoundException();
                }
            }
            catch (FlightNotFoundException e)
            {
                Console.WriteLine(e.Message);
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
        }
        public void GetFlightDetails()
        {
            try
            {
                
                Console.WriteLine("Enter Flight Number: ");
                int fn = Convert.ToInt32(Console.ReadLine());
                foreach (Commercial_Flight c in commflight)
                {
                    if (c.FlightNo == fn)
                    {
                        Console.WriteLine(c);
                        temp++;
                        break;
                    }
                }
                if (temp == 0)
                {
                    throw new FlightNotFoundException();
                }
            }
            catch (FlightNotFoundException e)
            {
                Console.WriteLine(e.Message);
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
        }
        public void GetSource()
        {
            try
            {
                
                Console.WriteLine("Enter Flight Number: ");
                int fn = Convert.ToInt32(Console.ReadLine());
                foreach (Commercial_Flight c in commflight)
                {
                    if (c.FlightNo == fn)
                    {
                        Console.WriteLine("Source :" + c.Source);
                        temp++;
                        break;
                    }
                }
                if (temp == 0)
                {
                    throw new FlightNotFoundException();
                }
            }
            catch (FlightNotFoundException e)
            {
                Console.WriteLine(e.Message);
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
        }


        public void GetDuration()
        {
            try
            {
                
                Console.WriteLine("Enter Flight Number: ");
                int fn = Convert.ToInt32(Console.ReadLine());
                foreach (Commercial_Flight c in commflight)
                {
                    if (c.FlightNo == fn)
                    {
                        float duration = (c.Distance / c.Speed) * 60;
                        Console.WriteLine(duration+ " mins");
                        temp++;
                        break;
                    }
                }
                if (temp == 0)
                {
                    throw new FlightNotFoundException();
                }
            }
            catch (FlightNotFoundException e)
            {
                Console.WriteLine(e.Message);
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
        }

        public void GetDestination()
        {
            try
            {
                Console.WriteLine("Enter the Flight Number: ");
                int fn = Convert.ToInt32(Console.ReadLine());
                foreach (Commercial_Flight c in commflight)
                {
                    if (c.FlightNo == fn)
                    {
                        Console.WriteLine("Destination :" + c.Destination);
                        temp++;
                        break;
                    }
                }
                if (temp == 0)
                {
                    throw new FlightNotFoundException();
                }
            }
            catch (FlightNotFoundException e)
            {
                Console.WriteLine(e.Message);
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
        }
        public void GetStartTime()
        {
            try
            {
                
                Console.WriteLine("Enter Flight Number: ");
                int fn = Convert.ToInt32(Console.ReadLine());
                foreach (Commercial_Flight c in commflight)
                {
                    if (c.FlightNo == fn)
                    {
                        Console.WriteLine("start time=" + c.StartTime);
                        temp++;
                        break;
                    }
                }
                if (temp == 0)
                {
                    throw new FlightNotFoundException();
                }
            }
            catch (FlightNotFoundException e)
            {
                Console.WriteLine(e.Message);
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
        }
        public void GetAvailability(int NoOfSeats)
        {
            try
            {

                Console.WriteLine("Enter the Flight Number: ");
                int fn = Convert.ToInt32(Console.ReadLine());
                foreach (Commercial_Flight c in commflight)
                {
                    if (c.FlightNo == fn)
                    {
                        if (c.AvailableSeats >= NoOfSeats)
                        {
                            Console.WriteLine("Available\n");
                            temp++;
                            break;
                        }
                        else
                        {
                            Console.WriteLine("Unavailable\n");
                            temp++;
                            break;
                        }
                    }
                }
                if (temp == 0)
                {
                    throw new FlightNotFoundException();
                }
            }
            catch (FlightNotFoundException e)
            {
                Console.WriteLine(e.Message);
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
        }
        public void listofavailableflights()
        {
            try
            {
                
                Console.WriteLine("Enter the Source Location: ");
                string src = Console.ReadLine();

                Console.WriteLine("Enter the Destination: ");
                string dest = Console.ReadLine();
                if (src == dest)
                    throw new SameSourceAndDestinationException();
                else
                {
                    foreach (Commercial_Flight c in commflight)
                    {
                        if (c.Source == src && c.Destination == dest)
                        {
                            Console.WriteLine("Flight Number:" + c.FlightNo + "   Start Time:" + c.StartTime);
                            temp++;
                        }
                    }
                    if (temp == 0)
                    {
                        Console.WriteLine("No flights available between " + src + " and " + dest + "..!!");
                    }
                }
            }
            catch (SameSourceAndDestinationException e)
            {
                Console.WriteLine(e.Message);
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
        }
    }

}
