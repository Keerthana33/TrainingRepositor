﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _496293_Flight
{
  sealed class CharterFlight : Flight
    {
        public CharterFlight()
        {
        }
        public CharterFlight(string type, int flightnum, int seatingcapacity, float speed, string owner, string baselocation, double mobilenumber)
        {
            Type = type;
            FlightNo = flightnum;
            SeatingCapacity = seatingcapacity;
            Speed = speed;
            Owner = owner;
            BaseLocation = baselocation;
            ContactNo = mobilenumber;

        }
        private string baselocation;
        private string owner;
        private double contactNo;

        public string BaseLocation
        {
            get { return baselocation; }
            set { baselocation = value; }
        }
        public string Owner
        {
            get { return owner; }
            set { owner = value; }
        }
        public double ContactNo
        {
            get { return contactNo; }
            set { contactNo = value; }
        }

        public override string ToString()
        {
            return "Type:" + Type + "\nFlight Number:" + FlightNo + "\nSeating Capacity:" + SeatingCapacity + "\nSpeed in kmph:" + Speed + "\nOwner:" + Owner + "\nBase station: " + BaseLocation + "\nContact Number: " + ContactNo+"\n";
        }

        public static int flightnumber = 30003;
        public int temp = 0;
        List<CharterFlight> charterflight = new List<CharterFlight>();
        public override void AddFlight(string type)
        {
            try
            {
                Console.WriteLine("Enter Seating Capacity: ");
                int capacity = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Enter Speed in kmph ");
                float speed = Convert.ToSingle(Console.ReadLine());
                Console.WriteLine("Enter Base location ");
                string BaseLocation = Console.ReadLine();
                if (BaseLocation == "")
                {
                    throw new EmptyString();
                }
                Console.WriteLine("Enter the Owner Name ");
                string Owner = Console.ReadLine();
                if (Owner == "")
                {
                    throw new EmptyString();
                }
                Console.WriteLine("Enter the Contact Number ");
                double ContactNo = Convert.ToDouble(Console.ReadLine());
                CharterFlight crf = new CharterFlight(type, flightnumber++, capacity, speed, Owner, BaseLocation, ContactNo);
                charterflight.Add(crf);

                Console.WriteLine("\nFlight added successfully\n");
                Console.WriteLine(crf+"\n");
            }
           
            catch (InvalidDetailsException e)
            {
                Console.WriteLine(e.Message);
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
        }
        public override void RemoveFlight()
        {
            try
            {
                Console.WriteLine("Enter the Flight Number: ");
                int flightno = Convert.ToInt32(Console.ReadLine());
                int i = 0;
                foreach (CharterFlight c in charterflight)
                {
                    if (c.FlightNo == flightno)
                    {
                        charterflight.RemoveAt(i);
                        Console.WriteLine("Flight removed successfully\n");
                        temp++;
                        break;
                    }
                    i++;
                }
                if (temp == 0)
                {
                    throw new FlightNotFoundException();
                }
            }
            catch (FlightNotFoundException e)
            {
                Console.WriteLine(e.Message);
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
        }
        public override void CalculateDuration()
        {
            try
            { 
                Console.WriteLine("Enter Flight Number: ");
                int fn = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Enter the distance to be travelled: ");
                int distance = Convert.ToInt32(Console.ReadLine());
                foreach (CharterFlight crf in charterflight)
                {
                    if (crf.FlightNo == fn)
                    {
                        float duration = (distance / crf.Speed) * 60;
                        Console.WriteLine(duration+" mins.");
                        temp++;
                        break;
                    }
                }
                if (temp == 0)
                {
                    throw new FlightNotFoundException();
                }
            }
            catch (FlightNotFoundException e)
            {
                Console.WriteLine(e.Message);
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
        }
        public void GetFlightDetails()
        {
            try
            {
                
                Console.WriteLine("Enter Flight Number: ");
                int fn = Convert.ToInt32(Console.ReadLine());
                foreach (CharterFlight cf in charterflight)
                {
                    if (cf.FlightNo == fn)
                    {
                        Console.WriteLine(cf);
                        temp++;
                        break;
                    }
                }
                if (temp == 0)
                {
                    throw new FlightNotFoundException();
                }
            }
            catch (FlightNotFoundException e)
            {
                Console.WriteLine(e.Message);
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
        }
    }
    }


