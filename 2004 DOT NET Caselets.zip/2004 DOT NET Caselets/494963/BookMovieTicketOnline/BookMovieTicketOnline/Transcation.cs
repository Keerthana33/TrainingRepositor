﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BookingonlineMovietc
{
    public class Transaction
    {
        private int orderNo;
        public int OrderNo { get { return orderNo; } set { orderNo = value; } }
        private int amount1;
        public int Amount { get { return amount1; } set { amount1 = value; } }
        private static int transactionId = 5000;
        public int TransactionId { get { return transactionId; } set { transactionId = value; } }
        private int transactionId2;
        public int TransactionId2 { get { return transactionId2; } set { transactionId2 = value; } }
        private int paymentMode;
        public int PaymentMode { get { return paymentMode; } set { paymentMode = value; } }
        private int cardSelection;
        public int CardSelection { get { return cardSelection; } set { cardSelection = value; } }
        private long cardNumber;
        public long CardNumber { get { return cardNumber; } set { cardNumber = value; } }
        public int NewTransaction(int orderno, List<Transaction> PassedTransactionList, int CalculatedAmount)
        {
            Transaction TransactionObject = new Transaction();
            TransactionObject.TransactionId2 = ++TransactionId;
            TransactionObject.Amount = CalculatedAmount;
            bool WhileLoopBooleanValidator = true;
            while (WhileLoopBooleanValidator)
            {
                Console.WriteLine("Select payment mode \n1.Online payment \n2.Cash on delivery");
                TransactionObject.PaymentMode = Convert.ToInt32(Console.ReadLine());
                if (TransactionObject.PaymentMode == 1 || TransactionObject.PaymentMode == 2)
                {
                    WhileLoopBooleanValidator = false;
                }
            }
            WhileLoopBooleanValidator = true;
            if (TransactionObject.PaymentMode == 1)
            {
                while (WhileLoopBooleanValidator)
                {
                    try
                    {
                        Console.WriteLine("\n Select 1.Debit card 2.Credit Card");
                        TransactionObject.CardSelection = Convert.ToInt32(Console.ReadLine());
                        if (TransactionObject.CardSelection == 1 || TransactionObject.CardSelection == 2)
                        {
                            WhileLoopBooleanValidator = false;
                        }
                    }
                    catch
                    {
                        new DataException();
                    }
                }
                WhileLoopBooleanValidator = true;
                while (WhileLoopBooleanValidator)
                {
                    try
                    {
                        Console.WriteLine("Enter 16 digit card number");
                        TransactionObject.CardNumber = Convert.ToInt64(Console.ReadLine());
                        if (TransactionObject.CardNumber > 999999999999999 && TransactionObject.CardNumber < 10000000000000000)
                            WhileLoopBooleanValidator = false;
                        else
                            new DataException();
                    }
                    catch
                    {
                        new DataException();
                    }

                }
                WhileLoopBooleanValidator = true;
            }
            else
            {
                Console.WriteLine("Collect the tickets and pay amount ");
            }

            PassedTransactionList.Add(TransactionObject);
            return TransactionObject.TransactionId2;
        }
        public void gettransaction(int ordno, List<Transaction> pass)
        {
            int check = 0;
            string paymode;
            foreach (Transaction a in pass)
            {
                Console.WriteLine("****************************************\t ");
                Console.WriteLine("\nTransaction id:{0}", a.TransactionId);
                Console.WriteLine("\nTransaction amount is\t {0}", a.Amount);
                if (a.PaymentMode == 1)
                {
                    paymode = "Online payment";
                    Console.WriteLine("\nMode of payment \t  {0}", paymode);
                    if (a.CardSelection == 1)
                    {
                        Console.WriteLine("\nPayment through debit card");
                    }
                    else
                    {
                        Console.WriteLine("\nPayment through credit card");
                    }
                    Console.WriteLine("\nCard number is \t {0}", a.CardNumber);
                }
                else
                    Console.WriteLine("Mode of payment \t  Cash on delivery");
                Console.WriteLine("************************\t ");
                check++;
            }
            if (check == 0)
            {
                new Exception();
            }
        }
    }
}


