﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BookingonlineMovietc
{
    public partial class Ticket
    {
        public int getticket(int orderri, List<Ticket> ticketlist)
        {
            bool a = true;
            Ticket tick = new Ticket();
            tick.OrdrId = orderri;
            int amount = 0;
            int forwardtoorder = 0;
            while (a)
            {
                try
                {
                    Console.WriteLine("\nPlease enter Showdate (dd-mm-yyyy)");
                    tick.ShowDate = Convert.ToDateTime(Console.ReadLine());
                    TimeSpan difference = ShowDate.Date - DateTime.Now;
                    if ((tick.ShowDate.Year - DateTime.Now.Year) >= 0 && (tick.ShowDate.Month - DateTime.Now.Month) >= 0 && (tick.ShowDate.Day - DateTime.Now.Day) > 0)
                        a = false;
                    else
                        new ChoiceException();
                }
                catch
                {
                    new DateException();
                }
               

            }
            //if (a)

            Console.WriteLine("ENTER TIME IN HH:MM FORMAT");
            tick.showTime = Convert.ToDateTime(Console.ReadLine());
            Console.WriteLine("***************************");
            Console.WriteLine("1.Carnival\n2.PVR\n3.INOX\n");
            Console.WriteLine("***************************");
            Console.WriteLine("Select Theatre");
            tick.TheatreName = Convert.ToInt32(Console.ReadLine());
            if (tick.TheatreName == 1)
            {
                Console.WriteLine("Thank you for choosing PVP");
                Console.WriteLine("Select a movie number");
                Console.WriteLine("*************************");
                Console.WriteLine("1.Dangal\n2.Raes\n3.Fastfurious");
                Console.WriteLine("*************************");
                tick.MovieName = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Each ticket costs 100");
                Console.WriteLine("Enter Number of seats");
                tick.NumberofSeats = Convert.ToInt16(Console.ReadLine());
                amount = tick.NumberofSeats * 100;
                Console.WriteLine("Each order amount is {0} \n Press 1 to continue\n 2 to cancel", amount);
                forwardtoorder = Convert.ToInt32(Console.ReadLine());
                if (forwardtoorder == 1)
                {
                    ticketlist.Add(tick);
                    return amount;
                }
                else
                {
                    Console.WriteLine("Transaction aborted");
                }
                return amount;
            }
            else if (tick.TheatreName == 2)
            {
                Console.WriteLine("Thank you for choosing PVR ");
                Console.WriteLine("Select a movie number");
                Console.WriteLine("****************************");
                Console.WriteLine("1.Dangal\n2.Raes\n3.Fastfurious");
                Console.WriteLine("*****************************");
                tick.MovieName = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Each ticket costs 150");
                Console.WriteLine("Enter Number of seats");
                tick.NumberofSeats = Convert.ToInt16(Console.ReadLine());
                amount = tick.NumberofSeats * 150;
                Console.WriteLine("Each order amount is {0} \n Press 1 to continue\n 2 to cancel", amount);
                forwardtoorder = Convert.ToInt32(Console.ReadLine());
                if (forwardtoorder == 1)
                {
                    ticketlist.Add(tick);
                    return amount;
                }
                else
                {
                    Console.WriteLine("Transaction aborted");
                }
                return amount;
            }
            else if (tick.TheatreName == 3)
            {
                Console.WriteLine("Thank you for choosing INOX ");
                Console.WriteLine("Select a movie number");
                Console.WriteLine("***************************");
                Console.WriteLine("1.Dangal\n2.Raes\n3.Fastfurious");
                Console.WriteLine("***************************");
                tick.MovieName = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Each ticket costs 130");
                Console.WriteLine("Enter Number of seats");
                tick.NumberofSeats = Convert.ToInt16(Console.ReadLine());
                amount = tick.NumberofSeats * 130;
                Console.WriteLine("Each order amount is {0} \n Press 1 to continue\n 2 to cancel", amount);
                forwardtoorder = Convert.ToInt32(Console.ReadLine());
                if (forwardtoorder == 1)
                {
                    ticketlist.Add(tick);
                    return amount;
                }
                else
                {
                    Console.WriteLine("Transaction aborted");
                }
                return amount;
            }
            else
            {
                return amount;
            }

        }
    }
}
