﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BookingonlineMovietc
{
    class AgeException : ApplicationException
    {
        public AgeException()
            : base()
        {
            Console.WriteLine("\nYour age is not sufficient");
        }
    }
    class Exception : ApplicationException
    {
        public Exception()
            : base()
        {
            Console.WriteLine("\n No details to display");
        }
    }
    class DataException : ApplicationException
    {
        public DataException() :
            base()
        {
            Console.WriteLine("\nEntered invalid data");
        }
    }

    class ChoiceException : ApplicationException
    {
        public ChoiceException() :
            base()
        {
            Console.WriteLine("\nEntered choice doesn't exist");
        }
    }
    class ValidationException : ApplicationException
    {
        public ValidationException() :
            base()
        {
            Console.WriteLine("\nInvalid Credentials");
        }
    }
    class DateException : ApplicationException
    {
        public DateException() :
            base()
        {
            Console.WriteLine("Entered date choice is invalid");
        }
    }
}
