﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _496498_HospitalManagementApp
{
    class DuesClearanceException : Exception
    {
        public DuesClearanceException()
            : base("Patient has due")
        {
        }
    }
}