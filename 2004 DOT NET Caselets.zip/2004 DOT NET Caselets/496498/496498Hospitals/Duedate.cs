﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _496498_HospitalManagementApp
{
    class DueDateException : Exception
    {
        public DueDateException()
            : base("Patient has not cleared balance")
        {
        }
    }
}