﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Caselet_Chair
{
    class chair
    {
        public int itemcode;
        private int price;
        public int Item_code
        {
            get;
            set;

        }
        public int Price
        {
            get;
            set;
        }

        public string Size { get; set; }
        public string Material { get; set; }
        public static int CountofChair = 0;

        public void MoveChair(int position1, int position2)
        {

        }




    }
    class rotating_chair : chair, IChairUser, IChairAdmin
    {
        public int DegreeOfRotation = 0;

        public rotating_chair(int itemcode, string size, string material, int price)
        {
            Item_code = itemcode;
            Size = size;
            Material = material;
            Price = price;
        }


        void IChairUser.Move(int pos1, int pos2)
        {
            Console.Write("You Cannot Move Rotating Chair");
        }

        void IChairAdmin.RemoveWheel(int wheel_no)
        {

            Console.Write("There are no wheels in a Rotaing Chair");
        }
        void IChairAdmin.AddWheel(int wheel_no)
        {

            Console.Write("You Cannot Add Wheel in a Rotating Chair");
        }

        void IChairAdmin.RotateChair(int degrees)
        {

            Console.Write("You Cannot Rotate a MovingChair");
        }


    }

    class wheel_chair : chair, IChairUser, IChairAdmin
    {
        int NoOfWheels = 4;

        public int positionx { get; set; }
        public int positiony { get; set; }


        public wheel_chair(int itemcode, string size, string material, int price)
        {
            Item_code = itemcode;
            Size = size;
            Material = material;
            Price = price;
        }

        public wheel_chair()
        {
            // TODO: Complete member initialization
        }
        void IChairAdmin.RotateChair(int degrees)
        {
            int rot;
            Console.WriteLine("Please confirm the rotation angle:");
            rot = Convert.ToInt32(Console.ReadLine());
            try
            {
                if (rot > 60)
                {
                    throw (new rotationexception());
                }
                else
                {
                    Console.WriteLine("The chair has been rotated to:{0}", rot);
                }

            }
            catch (rotationexception i)
            {
                Console.WriteLine(i.message);

            }


        }

        void IChairAdmin.AddWheel(int wheel_no)
        {
            NoOfWheels = wheel_no + NoOfWheels;
            Console.WriteLine("The Wheels are successfully added\nThe number of wheels are :{0}", NoOfWheels);


        }
        void IChairAdmin.RemoveWheel(int w)
        {

            Console.WriteLine("Please verify the number of wheels you want to remove:");
            w = Convert.ToInt16(Console.ReadLine());
            NoOfWheels = NoOfWheels - w;
            Console.WriteLine("The wheels are successfully removed \nThe new  number of wheels are:{0}", NoOfWheels);

        }



        public delegate int movedelegate(int pos1, int pos2);
        void IChairUser.Move(int pos1, int pos2)
        {
            Console.WriteLine("Old Position-->(" + positionx + "," + positiony + ")");
            positionx = positionx + pos1;
            positiony = positiony + pos2;
            Console.WriteLine("Current Position-->(" + positionx + "," + positiony + ")");

        }


    }

    interface IChairUser
    {
        void Move(int position1, int position2);


    }

    interface IChairAdmin
    {
        void RotateChair(int degree);
        void AddWheel(int wheel_no);
        void RemoveWheel(int wheel_no);

    }



    class WheelChairList : chair
    {

        int nbrofwheels;
        int position, wheelno;
        public int Now
        {
            get { return nbrofwheels; }
            set { if (value > 0) nbrofwheels = value; }
        }
        public int Pos
        {
            get { return position; }
            set { if (value > 0 && value < 5)position = value; }
        }
        public int Wheelno
        {
            get { return wheelno; }
            set { if (value > -1 && value < 3)wheelno = value; }
        }
        public WheelChairList()
        {
        }
        public WheelChairList(int a, int b, int c)
        {
            Pos = a;
            Wheelno = b;
            itemcode = c;
        }

    }
    class rotationexception : ApplicationException
    {
        public string message
        {
            get
            {
                return "Chair can be rotated only upto 60 degrees";
            }

        }
    }
}
