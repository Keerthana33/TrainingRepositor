﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace productcaselet
{
    class Program
    {
        static void Main(string[] args)
        {
            List<Product> p = new List<Product>();
            Product p1 = new Product();
            ProductOnDiscount p2 = new ProductOnDiscount();
            ProductOnSale p3 = new ProductOnSale();
            List<ProductOnSale> ps = new List<ProductOnSale>();
            List<ProductOnDiscount> pd = new List<ProductOnDiscount>();
            //var Product = new List<String>();
           

            //Console.WriteLine("Select any one of the follwoing:");
            //Console.WriteLine(" 1) Add Product 2) Remove Product 3)Modify Product 4)Copy a Product 5)Exit");
            int op, ch;
            
            do
            {
                Console.WriteLine("Select any one of the follwoing:");
                Console.WriteLine(" 1) Add Product\n 2) Remove Product\n 3)Modify Product \n 4)To know Discount of the product \n 5) To know quantity of product in Sale\n  6) Display \n  7)Exit");

                op = Convert.ToInt32(Console.ReadLine());

                switch (op)
                {
                    case 1: p1.AddProduct(p);

                              
                             break;
                    case 2:
                      Console.WriteLine("enter product id");
                             
                        p1.RemoveProduct(p1);
                        Console.WriteLine(p1.ToString());
                       
                        break;
                    case 3:
                       
                        //Console.WriteLine("Press\n1.To Change Name of Product\n2.To change Product code\n3.To change Category Code\n4.To Exit without Changing");
                        //Console.WriteLine("Enter your choice");
                        Console.WriteLine("Enter Product Code");
                        int a;
                        a = Convert.ToInt32(Console.ReadLine());

                        p1.ModifyProduct(a);
                        Console.WriteLine("The modified details of product is:");
                        Console.WriteLine(p1.ToString());
                        break;

                    case 4: int a1;
                           Console.WriteLine("Enter the productcode  of the product");
                           a1 = Convert.ToInt32(Console.ReadLine());
                           
                            p2.GetDiscountPercent(a1);
                            //p2.AddProduct();
                            break;
                    case 5: int a2;
                            Console.WriteLine("Enter the productcode  of the product");
                            a2 = Convert.ToInt32(Console.ReadLine());
                            p3.AddProduct(a2);
                            p3.GetQuantityOnSale();
                            break;
                    case 6:
                        Console.WriteLine("Sorted List is:");
                            //p.Sort();
                           foreach (Product i in p)
                           {
                                Console.WriteLine(i);
                          }
                            //p.Sort();
                            break;
                            
                    case 7: Console.WriteLine("Exiting.....");
                           break;
                    default: Console.WriteLine("Invalid Option");
                            break;
                    
                }
                Console.WriteLine("Do you want to continue(y/n)?:");
                ch = Convert.ToChar(Console.ReadLine());
            } while (ch == 'Y' || ch == 'y');

           
            p.Sort();
            
            Console.WriteLine("Sorted List is:");
            
        }

    }
}




//while (true)
//{

//    p1.AddProduct();
//    p.Add(p1);
//    //List<ProductOnSale> ps = new List<ProductOnSale>();
//    ProductOnSale ps1 = new ProductOnSale();
//    ps1.AddProduct(p1.ProductCode);
//    ps.Add(ps1);
//    p.Add(ps1);

//    Console.WriteLine("1 to exit");
//    if (Convert.ToInt16(Console.ReadLine()) == 1)
//        break;
//    else
//        continue;
//}
//foreach (ProductOnSale ps2 in ps)
//    Console.WriteLine( ps2.ToString());
//foreach (Product p2 in p)
//    Console.WriteLine( p2.ToString());
