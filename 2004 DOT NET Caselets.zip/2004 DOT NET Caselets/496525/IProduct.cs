﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace productcaselet
{
    interface IProduct
    {
        int GetProductCode(string PName);
        // List<string> GetAllProductCode();
        string GetProductDesc(int pcode);
        int GetCategoryCode(int pcode);
        double GetDiscountPercent(int pcode);
        double GetQuantityOnSale();

    }
}
