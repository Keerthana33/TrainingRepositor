﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Flight
{
    abstract class flight
    {

        private int flightNo;
        public string Type;
        private int seatingCapacity;
        private DateTime starttime;
        private int durationInMins;
        private int distance;
        private float speed;

        public int FlightNo
        {
            get { return flightNo; }
            set { flightNo = value; }
        }

        public string Typee
        {
            get { return Type; }
            set { Type = value; }
        }

        public int SeatingCapacity
        {
            get { return seatingCapacity; }
            set { seatingCapacity = value; }
        }
        public DateTime StartTime
        {
            get { return starttime; }
            set { starttime = value; }
        }
        public int DurationInMins
        {
            get { return durationInMins; }
            set { durationInMins = value; }
        }
        public int Distance
        {
            get { return distance; }
            set { distance = value; }
        }
        public float Speed
        {
            get { return speed; }
            set { speed = value; }
        }


        public abstract void AddFlight(string type);
        public abstract void RemoveFlight();
        public abstract void CalculateDuration();
        public bool IsAllLetters(string s)
        {
            foreach (char c in s)
            {
                if (!Char.IsLetter(c))
                    return false;
                break;
            }
            return true;
        }

    }
}




