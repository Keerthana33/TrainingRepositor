﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Flight
{
    sealed class charterflight : flight
    {

        public charterflight()
        {
        }
        public charterflight(string type, int flightnum, int seatingcapacity, float speed, string owner, string baselocation, double mobilenumber)
        {
            Type = type;
            FlightNo = flightnum;
            SeatingCapacity = seatingcapacity;
            Speed = speed;
            Owner = owner;
            BaseLocation = baselocation;
            ContactNo = mobilenumber;

        }
        private string baselocation;
        private string owner;
        private double contactNo;

        public string BaseLocation
        {
            get { return baselocation; }
            set { baselocation = value; }
        }
        public string Owner
        {
            get { return owner; }
            set { owner = value; }
        }
        public double ContactNo
        {
            get { return contactNo; }
            set { contactNo = value; }
        }

        public override string ToString()
        {
            return "types:" + Type + "\nFlight Number:" + FlightNo + "\nSeating Capacity:" + SeatingCapacity + "\nSpeed in kmph:" + Speed + "\nOwner:" + Owner + "\nBase station" + BaseLocation + "\nContact Number" + ContactNo;
        }

        public static int flightnumber = 11000;
        List<charterflight> ters = new List<charterflight>();
        public override void AddFlight(string type)
        {
            try
            {
                Console.WriteLine("Enter Seating Capacity ");
                int capacity = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Speed in kmph ");

                float speed = Convert.ToSingle(Console.ReadLine());
                Console.WriteLine("Enter Base location ");
                string BaseLocation = Console.ReadLine();
                if (!IsAllLetters(BaseLocation))
                    throw new InvalidDetailsException();
                Console.WriteLine("Enter the Owner Name ");
                string Owner = Console.ReadLine();
                if (!IsAllLetters(Owner))
                    throw new InvalidDetailsException();
                Console.WriteLine("Enter the Contact Number ");
                double ContactNo = Convert.ToDouble(Console.ReadLine());
                charterflight crf = new charterflight(type, flightnumber++, capacity, speed, Owner, BaseLocation, ContactNo);
                ters.Add(crf);

                Console.WriteLine("\nFlight details added successfully");
                Console.WriteLine(crf);
            }
            catch (InvalidDetailsException e)
            {
                Console.WriteLine(e.Message);
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
        }
        public override void RemoveFlight()
        {
            try
            {
                Console.WriteLine("Enter the Flight Number");
                int flightno = Convert.ToInt32(Console.ReadLine());
                int count = 0;
                int index = 0;
                foreach (charterflight crf in ters)
                {
                    if (crf.FlightNo == flightno)
                    {
                        ters.RemoveAt(index);
                        Console.WriteLine("Flight removed");
                        count++;
                        break;
                    }
                    index++;
                }
                if (count == 0)
                {
                    Console.WriteLine("Flight not found..!!");
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
        }
        public override void CalculateDuration()
        {
            try
            {
                int count = 0;
                Console.WriteLine("Enter Flight Number");

                int fn = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Enter the distance to be travelled");

                int distance = Convert.ToInt32(Console.ReadLine());
                foreach (charterflight crf in ters)
                {
                    if (crf.FlightNo == fn)
                    {
                        float duration = (distance / crf.Speed) * 60;
                        Console.WriteLine(duration);
                        count++;
                        break;
                    }
                }
                if (count == 0)
                {
                    Console.WriteLine("Flight not found");
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
        }
        public void GetFlightDetails()
        {
            try
            {
                int count = 0;
                Console.WriteLine("enter your Flight Number");
                int fn = Convert.ToInt32(Console.ReadLine());
                foreach (charterflight cf in ters)
                {
                    if (cf.FlightNo == fn)
                    {
                        Console.WriteLine(cf);
                        count++;
                        break;
                    }
                }
                if (count == 0)
                {
                    Console.WriteLine("flight not found");
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
        }
    }
}


