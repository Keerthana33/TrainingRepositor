﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace bookshop
{
    class Book
    {
        public string subject { get; set; }
        public int subject_id { get; set; }
        public int countOfBooks;

        public override string ToString()
        {
            return subject_id.ToString() + "\t" + subject.ToString() + "\t" + countOfBooks.ToString();
        }
    }
    interface ISalestax
    {

        void calculate_SalesTax(List<BooksOnAsubject> a);

    }



    class BooksOnAsubject : Book, ISalestax
    {

        public int isbnNumber;
        public string title;
        public string author;
        public double price;
        public Boolean inStock;
        public override string ToString()
        {
            return isbnNumber.ToString() + "\t" + title.ToString() + "\t" + author.ToString() + "\t" + price.ToString() +
                "\t" + inStock.ToString();
        }
        public void Add_book(List<BooksOnAsubject> a)
        {
            //public void BooksOnAsubject()
            Console.WriteLine("Enter isbnNumber , title, author, price");
            BooksOnAsubject s = new BooksOnAsubject();
            s.isbnNumber = Convert.ToInt32(Console.ReadLine());
            s.title = Convert.ToString(Console.ReadLine());
            s.author = Convert.ToString(Console.ReadLine());
            s.price = Convert.ToDouble(Console.ReadLine());
            a.Add(s);
            Console.WriteLine("Book inserted successfully");


        }

        public void delete_book(List<BooksOnAsubject> book1)
        {
            int booknum;
            int count = 0; int j = 0;

            Console.Write("Enter book number: ");
            booknum = Convert.ToInt32(Console.ReadLine());

            foreach (BooksOnAsubject b1 in book1)
            {
                if (b1.isbnNumber == booknum)
                {

                    book1.RemoveAt(count);
                    Console.WriteLine("Book was deleted");
                    j++;
                    break;

                }
                count++;

            }
            if (j == 0)
            {
                Console.WriteLine("No Books exist with that book number");
            }

        }



        public void display_allbooks(List<BooksOnAsubject> a)
        {
            foreach (BooksOnAsubject b1 in a)
            {
                Console.WriteLine(b1.ToString());
            }
        }
        public void modify_price(List<BooksOnAsubject> a)
        {
            int newprice;
            int booknum;
            int count = 0;

            Console.Write("Enter book number: ");
            booknum = Convert.ToInt32(Console.ReadLine());
            try
            {
                foreach (BooksOnAsubject b1 in a)
                {
                    if (b1.isbnNumber == booknum)
                    {
                        Console.Write("Enter New Price: ");
                        newprice = Convert.ToInt32(Console.ReadLine());
                        b1.price = newprice;
                        count++;
                    }

                }
                if (count == 0)
                {
                    throw (new NOBook());

                }
            }
            catch (NOBook ex)
            {
                Console.WriteLine(ex.msg2());
            }
        }

        public void searchByAuthor(List<BooksOnAsubject> a)
        {
            Console.WriteLine("Enter Author");
            string au = Console.ReadLine();
            int count = 0;

            foreach (BooksOnAsubject b1 in a)
            {
                if (b1.author == au)
                {
                    Console.WriteLine("  Subject       :{0}\n  Subject_id i:{1}\n  Count of Books  :{2}\n  isbn Number    :{3}\n  Title         :{4}\n  Author        :{5}\n  Price         :{6}\n  inStock       :{7}\n", b1.subject, b1.subject_id, b1.countOfBooks, b1.isbnNumber, b1.title, b1.author, b1.price, b1.inStock);
                    count++;
                }

            }
            if (count == 0)
            {
                Console.WriteLine("No such Author");
            }
        }
        public void searchByTitle(List<BooksOnAsubject> a)
        {
            int count = 0;
            Console.WriteLine("Enter Title");
            string t = Console.ReadLine();
            try
            {
                foreach (BooksOnAsubject b1 in a)
                {
                    if (b1.title == t)
                    {
                        Console.WriteLine("  Subject       :{0}\n  Subject_id i:{1}\n  Count of Books  :{2}\n  isbn Number    :{3}\n  Title         :{4}\n  Author        :{5}\n  Price         :{6}\n  inStock       :{7}\n", b1.subject, b1.subject_id, b1.countOfBooks, b1.isbnNumber, b1.title, b1.author, b1.price, b1.inStock);
                        count++;
                    }

                }
                if (count == 0)
                {
                    throw (new NOBook());
                }
            }
            catch (NOBook ex)
            {
                Console.WriteLine(ex.msg2());
            }
        }
        public void check_available(List<BooksOnAsubject> a)
        {
            int count = 0;
            try
            {
                Console.WriteLine("Enter Title");
                string t = Console.ReadLine();
                foreach (BooksOnAsubject b1 in a)
                {
                    if (b1.title == t && b1.inStock == true)
                    {
                        Console.WriteLine("Available");
                        count++;
                    }

                }
                if (count == 0)
                {

                    throw (new NotAvailable());

                }
            }
            catch (NotAvailable ex)
            {
                Console.WriteLine(ex.msg1());
            }
        }
        public void calculate_SalesTax(List<BooksOnAsubject> a)
        {
            int booknum;
            int count = 0;

            Console.Write("Enter Book number: ");
            booknum = Convert.ToInt32(Console.ReadLine());
            foreach (BooksOnAsubject b1 in a)
            {
                if (b1.isbnNumber == booknum)
                {
                    double salestax = 0.045 * b1.price;
                    Console.WriteLine("Sales Tax:Rs.{0}", salestax);
                    count++;
                }

            }
            if (count == 0)
                Console.WriteLine("No Books exist with that book number");


        }
        class Userdefinedexception : ApplicationException
        {
            public string msg()
            {
                return "enter correct details";
            }
        }
        class NotAvailable : ApplicationException
        {
            public string msg1()
            {
                return "Not Available";
            }
        }
        class NOBook : ApplicationException
        {
            public string msg2()
            {
                return "No Book found";
            }
        }
    }
    class program
    {
        static void Main(string[] args)
        {
            List<Book> book = new List<Book>() {new Book() {subject_id=1,subject="Physics",countOfBooks=5},
            new Book() {subject_id=2, subject="Chem",countOfBooks=5}, 
            new Book() {subject_id=3, subject="Math", countOfBooks=5}};
            foreach (Book b4 in book)
            {
                Console.WriteLine(b4.ToString());
            }
            List<BooksOnAsubject> a = new List<BooksOnAsubject>(){new BooksOnAsubject() 
                {isbnNumber= 01, title="physics1",author="A",price=250 ,inStock=true},
                new BooksOnAsubject(){isbnNumber= 02, title="physics2",author="B",price=250 ,inStock=true},
                new BooksOnAsubject(){isbnNumber= 03, title="physics3",author="C",price=250 ,inStock=true},
                new BooksOnAsubject(){isbnNumber= 04, title="physics4",author="D",price=250 ,inStock=true},
                new BooksOnAsubject(){isbnNumber= 05, title="physics5",author="E",price=250 ,inStock=true},new BooksOnAsubject() 
                {isbnNumber= 06, title="Chem1",author="E",price=250 ,inStock=true},
                new BooksOnAsubject(){isbnNumber= 07, title="Chem2",author="F",price=250 ,inStock=true},
                new BooksOnAsubject(){isbnNumber= 08, title="Chem3",author="G",price=250 ,inStock=true},
                new BooksOnAsubject(){isbnNumber= 09, title="Chem4",author="H",price=250 ,inStock=true},
                new BooksOnAsubject(){isbnNumber= 10, title="Chem5",author="I",price=250 ,inStock=true},
            new BooksOnAsubject() 
                {isbnNumber= 11, title="Math1",author="J",price=250 ,inStock=true},
                new BooksOnAsubject(){isbnNumber= 12, title="Math2",author="K",price=250 ,inStock=true},
                new BooksOnAsubject(){isbnNumber= 13, title="Math3",author="L",price=250 ,inStock=true},
                new BooksOnAsubject(){isbnNumber= 14, title="Math4",author="M",price=250 ,inStock=true},
                new BooksOnAsubject(){isbnNumber= 15, title="Math5",author="N",price=250 ,inStock=true}};
            BooksOnAsubject b = new BooksOnAsubject();
            foreach (BooksOnAsubject b1 in a)
            {
                Console.WriteLine(b1.ToString());
            }
            while (true)
            {
                Console.WriteLine("\t Select your option:");
                Console.WriteLine("**********************************");
                Console.WriteLine(" 1:Add Book\n 2:Delete Book\n 3:Display all books\n 4:modify the price of a book\n 5:Search by author\n 6:Search by title\n 7:Check Availability\n 8:Exit");
                Console.WriteLine("**********************************");
                int i = Convert.ToInt16(Console.ReadLine());


                switch (i)
                {
                    case 1:
                        b.Add_book(a);
                        break;
                    case 2:
                        b.delete_book(a);
                        break;
                    case 3:
                        b.display_allbooks(a);
                        break;
                    case 4:
                        b.modify_price(a);
                        break;
                    case 5:
                        b.searchByAuthor(a);
                        break;
                    case 6:
                        b.searchByTitle(a);
                        break;
                    case 7:
                        b.check_available(a);
                        break;
                    case 8:
                        break;
                }
                Console.WriteLine("If you want to exit press y and if not press n");
                Char e = Convert.ToChar(Console.ReadLine());
                if (e.Equals('y') || e.Equals('Y'))
                {
                    break;
                }
                else
                {
                    continue;
                }

            }
        }
    }
}






















