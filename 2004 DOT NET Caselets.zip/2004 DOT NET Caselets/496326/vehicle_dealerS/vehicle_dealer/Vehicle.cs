﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace vehicle_dealer
{
    public class Vehicle
    {
        public static int count;
        public string type;
        public int id;
        public int Vid
        {
            get
            {
                return id;
            }
        }
        public void Vehicle1()
        {
            id = count;
            count++;
        }

        private string vehicleName;
        public string name
        {
            get { return vehicleName; }
            set { vehicleName = value; }
        }
        private int noOfModels;
        public int noOfmodels
        {
            get { return noOfModels; }
            set { noOfModels = value; }
        }


    }
}
