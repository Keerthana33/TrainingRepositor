﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace vehicle_dealer
{
    class deleteunderflow
    {
        public deleteunderflow() : base()
        {
            Console.ForegroundColor = ConsoleColor.DarkGreen;
            Console.WriteLine("No model to delete");
            Console.ForegroundColor = ConsoleColor.White;
        }
    }
}
