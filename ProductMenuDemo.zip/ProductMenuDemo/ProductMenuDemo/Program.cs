﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using RepositoryPattern;

namespace ProductMenuDemo
{
    class Program
    {
        static Repository<Product> rep=new Repository<Product>();
        static Product pr = new Product();
        static void Main(string[] args)
        {            
            while (true)
            {
                Console.WriteLine("Enter your choice");
                Console.WriteLine("1.Insert Product \n2.Product Details \n3.Edit/Update Product Information \n4.Delete Product \n5.Display Products");
                int choice = 0;
                Int32.TryParse(Console.ReadLine(), out choice);
                if (choice == 0 || choice > 5 && choice<0)
                {
                    continue;
                }
                else
                {
                    switch (choice)
                    {
                        case 1:
                            insertProduct();
                            break;

                        case 2:
                            DisplayProductDetails();
                            break;

                        case 5:
                            DisplayProduct();
                            break;
                    }
                    //do
                    //{
                    //    Console.WriteLine("Do you want to continue? Enter Y/N");
                    //    string op = Console.ReadLine().ToUpper();
                    //    if (op != "Y" || op != "N")
                    //    {
                    //        Console.WriteLine("Wrong Choice or invalid input..Please enter correct option");
                    //        continue;
                    //    }
                    //    else
                    //    {

                    //    }
                    //} while ();
                }
                

            }
        }

        private static void DisplayProduct()
        {
            var pro1 = rep.Display().ToList();
            foreach (var item in pro1)
            {
                Console.WriteLine($" The  records are {item.ProductName} {item.ProductNumber} {item.ProductPrice}");
            }
            Console.ReadLine();
        }

        private static void DisplayProductDetails()
        {
            while (true)
            {
                Console.WriteLine("Enter Product Number whose information you want to display:");
                string productno = Console.ReadLine();
                int pno;
                bool result = Int32.TryParse(productno, out pno);
                if (!result)
                {
                    Console.WriteLine("Invalid Format!! Re-enter product Number");
                    continue;
                }
                else if (!(rep.ProductExists(pno)))
                {
                    Console.WriteLine("Product Number doesn't exist");
                    continue;
                }
                else
                {
                    var pro=rep.GetProduct(pno);
                    Console.WriteLine($"Product information:\n {pro.ProductNumber} {pro.ProductName} {pro.ProductPrice}");
                    Console.ReadLine();
                    break;
                }
            }
        }

        private static void insertProduct()
        {
            pr = new Product { ProductName = Console.ReadLine(),
                                       ProductNumber= Convert.ToInt32(Console.ReadLine()),
                                       ProductPrice = Convert.ToInt32(Console.ReadLine())
            };
            rep.Insert(pr);
        }
    } 

   

}
