﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace RepositoryPattern
{
    public class Repository<T> :  IRepository<T> where T : Product
    {

        List<T> product = new List<T>();

        public void Insert(T pro)
        {
            product.Add(pro);
        }

        public void Delete(T entity)
        {
            
        }

        public IEnumerable<T> Display()
        {

            return product;

        }

       
        public bool ProductExists(int id)
        {
            var productbyid = product.Where(p => p.ProductNumber == id).FirstOrDefault();
            if (productbyid == null)
            {
                return false;
            }
            return true;

        }

        public T GetProduct(int pnum)
        {
            return product.Where(p => p.ProductNumber == pnum).FirstOrDefault();
        }


    }

    public interface IRepository<T> where T : Product//EntityBase
    {
        bool ProductExists(int id);

        void Insert(T entity);

        void Delete(T entity);

        IEnumerable<T> Display();
        T GetProduct(int pnum);
    }

  public   class Product
    {
        public string ProductName { get; set; }
        public int ProductNumber { get; set; }
        public int ProductPrice { get; set; }
    }

}