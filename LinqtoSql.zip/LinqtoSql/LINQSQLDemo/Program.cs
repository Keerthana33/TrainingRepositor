﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;

namespace LINQSQLDemo
{
    class Program
    {
        static void Main(string[] args)
        {

            string connection = ConfigurationManager.ConnectionStrings["LINQSQLDemo.Properties.Settings.NorthwindConnectionString"].ToString();
            DataClasses1DataContext db = new  DataClasses1DataContext(connection);

            /* Create a new record in to the table 
            Employee emp = new Employee();
            emp.EmployeeID = 14;
            emp.FirstName = "Harika";
            emp.LastName = "Nallagatla";

            db.Employees.InsertOnSubmit(emp);

            db.SubmitChanges();

     */

            /*Update the record of the table

            var updaterecord = db.Employees.FirstOrDefault(e => e.FirstName.Equals("Harika"));

            if (updaterecord != null)
            {
                updaterecord.FirstName = "Lakshmi";
                db.SubmitChanges();
            }
            */

            /*DElete the record*/

            var deleterecord = db.Employees.FirstOrDefault(e => e.FirstName.Equals("Lakshmi"));

            db.Employees.DeleteOnSubmit(deleterecord);
            db.SubmitChanges();

        }
    }
}
