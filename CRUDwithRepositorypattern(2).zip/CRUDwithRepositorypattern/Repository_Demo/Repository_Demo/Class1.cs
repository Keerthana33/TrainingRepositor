﻿
using System.Collections.Generic;
using System.Data.Entity;

namespace RepositoryPattern
{
    public class Repository<T> : DbContext, IRepository<T> where T : class//EntityBase
    {
        private readonly DbContext db;/*= new DbContext();*/
        DbSet<T> dbset;

        public Repository(DbContext context)
        {
            db = context;
        }

        public void Insert(T entity)
        {
            db.Set<T>().Add(entity);
        }

        public void Delete(T entity)
        {
            dbset = db.Set<T>();
            dbset.Remove(entity);
        }

        public IEnumerable<T> Display()
        {

            return db.Set<T>();
                
        }

        public T GetById(int id)
        {
            return db.Set<T>().Find(id);
        }

       
    }

    public interface IRepository<T> where T : class//EntityBase

    {

        T GetById(int id);

        void Insert(T entity);

        void Delete(T entity);

        IEnumerable<T> Display();

    }

    
}