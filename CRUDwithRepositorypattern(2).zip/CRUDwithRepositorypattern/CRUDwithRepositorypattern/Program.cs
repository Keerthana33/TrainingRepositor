﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using RepositoryPattern;

namespace CRUDwithRepositorypattern
{
    class Program
    {
        static Repository<Employee> rep;

        static NorthwindEntities db;
        static void Main(string[] args)
        {
            db = new NorthwindEntities();
            rep = new Repository<Employee>(db);
            displayRecords();
           // insertRecords();
            Console.WriteLine("---------------After inserting the record---------");
            displayRecords();
           // deleteRecord();
            Console.WriteLine("----------------After deleting the data-------------");
            displayRecords();
            getElementById();
            Console.ReadLine();
        }

        private static void getElementById()
        {
            var emp = rep.GetById(26);
            Console.WriteLine($"Inside getElementById {emp.EmployeeID} {emp.FirstName}");
        }

        private static void deleteRecord()
        {
            var emp1 = db.Employees.Where(e => e.EmployeeID == 27).FirstOrDefault();
            rep.Delete(emp1);
            db.SaveChanges();
        }

        private static void displayRecords()
        {
            var emp1 = rep.Display().ToList();
            foreach (var item in emp1)
            {
                Console.WriteLine($" The  records are {item.FirstName} {item.EmployeeID}");
            }
            Console.ReadLine();
        }

        private static void insertRecords()
        {
            Employee emp = new Employee { FirstName = "Harika", LastName = "Nallagatla" };
            rep.Insert(emp);
            db.SaveChanges();
        }
    }
}
