﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace custom_validator
{
    public partial class c1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        protected void Button1_Click(object sender, EventArgs e)
        {
            if(Page.IsValid)
            {
                lblStatus.Text = "Data sAVED";
               
            }
            else
            {
                lblStatus.Text = "VALIDATION ERROR";
                lblStatus.ForeColor = System.Drawing.Color.Red;
            }

        }

        protected void CustomValidatoreven_ServerValidate(object source, ServerValidateEventArgs args)
        {
            if (args.Value == "")
            {
                args.IsValid = false;
            }
            else
            {
                int Number;
                bool isNumber = int.TryParse(args.Value, out Number);
                 
               // if (Convert.ToInt32(args.Value) % 2 == 0)

               if(isNumber&& Number>=0 && Number%2==0)
                {
                    args.IsValid = true;
                }
                else
                {
                    args.IsValid = false;
                }
            }
        }
     
    }
}