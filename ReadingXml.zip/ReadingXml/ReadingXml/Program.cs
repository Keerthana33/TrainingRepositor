﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace ReadingXml
{
    class Program
    {
        static void Main(string[] args)
        {
            XDocument document = XDocument.Load("Database\\product.xml");
            document.Descendants("product").Select(p => new
            {
                id =p.Attribute("id").Value,
               name = p.Element("name").Value,
               price = p.Element("price").Value,
                currency = p.Element("price").Attribute("currency").Value
            }).ToList().ForEach( p => {
                Console.WriteLine("id: " + p.id);
                Console.WriteLine("name:" + p.name);
                Console.WriteLine("price:"+p.price);
                Console.WriteLine("currency:"+p.currency);
                Console.WriteLine("==================");
            });


           
            
            Console.ReadLine();
            
        }
    }
}
