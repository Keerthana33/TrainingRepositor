﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace caseletexam
{
    public abstract class AirportEssentials
    {
        public  int airportid;
        public string airportname;
        public string cityname;
        public int allotedareaforairport;
        public int allotedareaforparking;
        public string address;
        public AirportEssentials()
        {
           this. airportid = genRandomnum();
        }
        public virtual void AddNewAirport() { }
        public virtual void RemoveAirport() { }
        public virtual void EditAirportDetails() { }
        public virtual void GetDetailsForNewAirport() { }
        public virtual void ShowAirportDetails() { }
        public static  int genRandomnum()
        {
            int airid=0;
            Random r = new Random();
            string w = "";
            int i;
            for (i = 1; i < 5; i++)
            {
                w += r.Next(0, 9).ToString();
            }
           
                airid = Convert.ToInt32(w);

            
            return airid;
        }
    }
}





