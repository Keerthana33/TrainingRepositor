﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace caseletexam
{
   
        class MaxFlightsperday : Exception
        {
            public MaxFlightsperday(string message) : base(message) { }
        }

        class MinFlightsperday : Exception
        {
            public MinFlightsperday(string message) : base(message) { }
        }
        class MinRequiredArea : Exception
        {
            public MinRequiredArea(string message) : base(message) { }
        }
    
}
